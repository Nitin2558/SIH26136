const { getDB, resetDB, generateId } = require('./db/store');

function seedDatabase() {
  console.log('[Seed] Generating comprehensive seed dataset (~20 problems, sample users, workspace)...');

  // 1. Users
  const users = [
    {
      id: 'usr-citizen-1',
      name: 'Rajesh Sharma',
      email: 'rajesh@example.com',
      role: 'citizen',
      locationState: 'Maharashtra',
      createdAt: new Date().toISOString()
    },
    {
      id: 'usr-govt-1',
      name: 'Dr. Sunita Verma',
      email: 'sunita.verma@gov.in',
      role: 'government',
      departmentName: 'Department of Urban Infrastructure & Water Resources',
      locationState: 'Maharashtra',
      createdAt: new Date().toISOString()
    },
    {
      id: 'usr-univ-1',
      name: 'Priya Patel (IIT Bombay Research Team)',
      email: 'team.lead@iitb.ac.in',
      role: 'university',
      universityName: 'IIT Bombay',
      createdAt: new Date().toISOString()
    },
    {
      id: 'usr-ind-1',
      name: 'Anil Mehta (TechCorp Ventures)',
      email: 'mentor@techcorp.com',
      role: 'industry',
      orgName: 'TechCorp Innovations & CleanTech Fund',
      createdAt: new Date().toISOString()
    },
    {
      id: 'usr-admin-1',
      name: 'System Admin',
      email: 'admin@civic-innovation.gov.in',
      role: 'admin',
      createdAt: new Date().toISOString()
    }
  ];

  // 2. Problems (~20 items)
  const problems = [
    // --- RESEARCH-WORTHY (High Confidence >= 0.85) ---
    {
      id: 'prob-rw-1',
      title: 'Smart Flood Warning System for River Areas',
      description: 'River water rises quickly during heavy monsoon rains and floods nearby houses and streets without warning. We need smart water-level sensors and an alert system to warn residents 4 hours before water enters their homes.',
      category: 'Infrastructure',
      canBeAddressed: 'Yes',
      locationState: 'Maharashtra',
      locationDistrict: 'Pune',
      submitterType: 'government',
      submitterId: 'usr-govt-1',
      submitterName: 'Dr. Sunita Verma',
      departmentName: 'Department of Urban Infrastructure & Water Resources',
      status: 'research-worthy',
      confidence: 0.94,
      heuristicScore: 0.92,
      aiReason: 'Sensors and smart flood warning software can give families time to evacuate before rising water reaches residential areas.',
      isAggregated: false,
      sourceProblemIds: [],
      upvotes: 42,
      downvotes: 1,
      createdAt: new Date(Date.now() - 10 * 86400000).toISOString()
    },
    {
      id: 'prob-rw-2',
      title: 'Generating Clean Electricity from Flowing Drain Water',
      description: 'Water rushes quickly through underground municipal sewer pipes in hilly towns. We need small, clog-resistant turbines inside the drain pipes to turn this rushing water into electricity for local streetlights.',
      category: 'Technology gap',
      canBeAddressed: 'Yes',
      locationState: 'Himachal Pradesh',
      locationDistrict: 'Shimla',
      submitterType: 'government',
      submitterId: 'usr-govt-1',
      submitterName: 'Shimla Renewable Energy Cell',
      departmentName: 'Dept of Renewable Energy',
      status: 'research-worthy',
      confidence: 0.91,
      heuristicScore: 0.88,
      aiReason: 'Using fast-flowing drain water to spin small turbines creates clean energy for street lighting.',
      isAggregated: false,
      sourceProblemIds: [],
      upvotes: 29,
      downvotes: 2,
      createdAt: new Date(Date.now() - 8 * 86400000).toISOString()
    },
    {
      id: 'prob-rw-3',
      title: 'Solar-Powered Floating Boat to Clean River Garbage',
      description: 'City canals and rivers are choked with floating plastic bottles and trash. We need a small, solar-powered floating robot boat that scoops up floating plastic and keeps the river clean.',
      category: 'Environment',
      canBeAddressed: 'Yes',
      locationState: 'Tamil Nadu',
      locationDistrict: 'Chennai',
      submitterType: 'citizen',
      submitterId: 'usr-citizen-1',
      submitterName: 'Clean Canals Collective',
      status: 'research-worthy',
      confidence: 0.92,
      heuristicScore: 0.89,
      aiReason: 'A solar-powered floating boat with cameras can automatically collect plastic waste from city waterways.',
      isAggregated: false,
      sourceProblemIds: [],
      upvotes: 56,
      downvotes: 3,
      createdAt: new Date(Date.now() - 7 * 86400000).toISOString()
    },
    {
      id: 'prob-rw-4',
      title: 'Early Heat Alert System for Forest Fires',
      description: 'Forest fires start silently near village borders and spread quickly before firefighters can react. We need satellite heat maps and small drones to detect fires within minutes and protect nearby communities.',
      category: 'Environment',
      canBeAddressed: 'Yes',
      locationState: 'Maharashtra',
      locationDistrict: 'Chandrapur',
      submitterType: 'government',
      submitterId: 'usr-govt-1',
      submitterName: 'State Forest Conservation Board',
      departmentName: 'Forestry & Disaster Mgmt',
      status: 'research-worthy',
      confidence: 0.89,
      heuristicScore: 0.86,
      aiReason: 'Detecting fire hotspots early using satellite data and drones helps forest rangers stop small fires before they spread.',
      isAggregated: false,
      sourceProblemIds: [],
      upvotes: 38,
      downvotes: 0,
      createdAt: new Date(Date.now() - 6 * 86400000).toISOString()
    },
    {
      id: 'prob-rw-5',
      title: 'Low-Cost Solar Filter for Poisonous Well Water',
      description: 'Drinking water from village borewells contains dangerous arsenic that makes families sick. We need an affordable solar water filter that removes arsenic safely without wasting clean water.',
      category: 'Health',
      canBeAddressed: 'Yes',
      locationState: 'West Bengal',
      locationDistrict: 'Malda',
      submitterType: 'citizen',
      submitterId: 'usr-citizen-1',
      submitterName: 'Rural Water Safety Forum',
      status: 'research-worthy',
      confidence: 0.95,
      heuristicScore: 0.90,
      aiReason: 'A low-cost solar water filter to remove arsenic directly addresses a major drinking water health crisis.',
      isAggregated: false,
      sourceProblemIds: [],
      upvotes: 67,
      downvotes: 1,
      createdAt: new Date(Date.now() - 5 * 86400000).toISOString()
    },
    {
      id: 'prob-rw-6',
      title: 'Smart Camera Traffic Lights to Reduce Traffic Jams',
      description: 'Old timer traffic lights keep cars waiting at empty roads while emergency ambulances get stuck in jams. We need camera-based smart signals that automatically give green lights to busy lanes and passing ambulances.',
      category: 'Technology gap',
      canBeAddressed: 'Yes',
      locationState: 'Karnataka',
      locationDistrict: 'Bengaluru',
      submitterType: 'government',
      submitterId: 'usr-govt-1',
      submitterName: 'Bengaluru Traffic Management Directorate',
      departmentName: 'Traffic Police & Urban Mobility',
      status: 'research-worthy',
      confidence: 0.93,
      heuristicScore: 0.91,
      aiReason: 'Smart camera traffic lights adjust signals based on actual road traffic to clear road blocks and emergency vehicles.',
      isAggregated: false,
      sourceProblemIds: [],
      upvotes: 74,
      downvotes: 4,
      createdAt: new Date(Date.now() - 4 * 86400000).toISOString()
    },
    {
      id: 'prob-rw-7',
      title: 'Turning Rotten Market Vegetables into Clean Cooking Gas',
      description: 'Wholesale vegetable markets throw away tons of rotting vegetables every day. We need a compact machine inside the market that turns rotten veggies into free, clean cooking biogas.',
      category: 'Data & awareness',
      canBeAddressed: 'Yes',
      locationState: 'Delhi',
      locationDistrict: 'Azadpur',
      submitterType: 'government',
      submitterId: 'usr-govt-1',
      submitterName: 'Delhi Agricultural Marketing Board',
      departmentName: 'Agricultural Produce Board',
      status: 'research-worthy',
      confidence: 0.88,
      heuristicScore: 0.87,
      aiReason: 'Recycling market food waste into cooking biogas produces clean local energy and stops dirty roadside dumping.',
      isAggregated: false,
      sourceProblemIds: [],
      upvotes: 31,
      downvotes: 1,
      createdAt: new Date(Date.now() - 3 * 86400000).toISOString()
    },

    // --- AMBIGUOUS / NEEDS REVIEW (Confidence 0.50 - 0.84) ---
    {
      id: 'prob-nr-1',
      title: 'Testing Sudden Salty Well Water in Barmer Villages',
      description: 'Drinking well water in 12 villages has suddenly turned salty and undrinkable. We need simple water-testing kits and digital sensors to find out where the pollution is coming from.',
      category: 'Data & awareness',
      canBeAddressed: 'Not sure',
      locationState: 'Rajasthan',
      locationDistrict: 'Barmer',
      submitterType: 'citizen',
      submitterId: 'usr-citizen-1',
      submitterName: 'Barmer Kisan Welfare Society',
      status: 'needs-review',
      confidence: 0.68,
      heuristicScore: 0.60,
      aiReason: 'Requires testing whether the salt is natural or caused by nearby factory waste.',
      isAggregated: false,
      sourceProblemIds: [],
      upvotes: 8,
      downvotes: 2,
      createdAt: new Date(Date.now() - 2 * 86400000).toISOString()
    },
    {
      id: 'prob-nr-2',
      title: 'Detecting Dangerous Road Potholes using Bus Cameras',
      description: 'Potholes appear after every rain and cause scooter accidents. Can we install small cameras on city buses to automatically find and report dangerous potholes for quick repair?',
      category: 'Infrastructure',
      canBeAddressed: 'Yes',
      locationState: 'Delhi',
      locationDistrict: 'Central Delhi',
      submitterType: 'citizen',
      submitterId: 'usr-citizen-1',
      submitterName: 'Vikram Malhotra',
      status: 'needs-review',
      confidence: 0.74,
      heuristicScore: 0.70,
      aiReason: 'Mounting cameras on city buses to map potholes combines civic road repair with smart camera detection.',
      isAggregated: false,
      sourceProblemIds: [],
      upvotes: 14,
      downvotes: 1,
      createdAt: new Date(Date.now() - 2 * 86400000).toISOString()
    },
    {
      id: 'prob-nr-3',
      title: 'Automatic Machine to Separate Wet and Dry Waste',
      description: 'Sanitation workers have to sort dirty mixed garbage by hand every morning. We need an automated conveyor belt machine that separates plastic bottles from organic wet waste.',
      category: 'Environment',
      canBeAddressed: 'Not sure',
      locationState: 'Gujarat',
      locationDistrict: 'Ahmedabad',
      submitterType: 'citizen',
      submitterId: 'usr-citizen-1',
      submitterName: 'Ahmedabad Green Forum',
      status: 'needs-review',
      confidence: 0.71,
      heuristicScore: 0.65,
      aiReason: 'Using simple sensors on a conveyor belt to sort trash protects sanitation workers from handling hazardous waste.',
      isAggregated: false,
      sourceProblemIds: [],
      upvotes: 12,
      downvotes: 0,
      createdAt: new Date(Date.now() - 1 * 86400000).toISOString()
    },
    {
      id: 'prob-nr-4',
      title: 'Automatic Honk Detectors for Hospital Silent Zones',
      description: 'Loud vehicle honking outside the hospital disturbs emergency and ICU patients. We need sound sensors that detect loud honking and automatically take photos of violating vehicles.',
      category: 'Health',
      canBeAddressed: 'Yes',
      locationState: 'Maharashtra',
      locationDistrict: 'Pune',
      submitterType: 'citizen',
      submitterId: 'usr-citizen-1',
      submitterName: 'Dr. K. R. Kulkarni',
      status: 'needs-review',
      confidence: 0.78,
      heuristicScore: 0.72,
      aiReason: 'Sound sensors that pinpoint loud honking help enforce quiet zones around hospitals.',
      isAggregated: false,
      sourceProblemIds: [],
      upvotes: 19,
      downvotes: 1,
      createdAt: new Date(Date.now() - 1 * 86400000).toISOString()
    },

    // --- GENERAL GRIEVANCES (Low Confidence < 0.50, English & Hinglish) ---
    {
      id: 'prob-gr-1',
      title: 'Streetlight broken for 4 days near Shivaji Nagar',
      description: 'In Shivaji Nagar lane 3, the streetlight bulb has fused. It is completely dark at night and unsafe for walking. Please send an electrician to replace the bulb.',
      category: 'Infrastructure',
      canBeAddressed: 'No',
      locationState: 'Maharashtra',
      locationDistrict: 'Pune',
      submitterType: 'citizen',
      submitterId: 'usr-citizen-1',
      submitterName: 'Ramesh Sonawane',
      status: 'general-grievance',
      confidence: 0.22,
      heuristicScore: 0.15,
      aiReason: 'Routine local municipal streetlight bulb replacement complaint. No new engineering or research needed.',
      isAggregated: false,
      sourceProblemIds: [],
      upvotes: 2,
      downvotes: 0,
      createdAt: new Date(Date.now() - 15 * 86400000).toISOString()
    },
    {
      id: 'prob-gr-2',
      title: 'Large pothole on Station Road causing scooter slips',
      description: 'Near Central Bank on Station Road, a large pothole was formed after the recent rains. Two two-wheelers already slipped. Please ask the municipal team to fill it with asphalt.',
      category: 'Infrastructure',
      canBeAddressed: 'No',
      locationState: 'Maharashtra',
      locationDistrict: 'Pune',
      submitterType: 'citizen',
      submitterId: 'usr-citizen-1',
      submitterName: 'Sunil Deshmukh',
      status: 'general-grievance',
      confidence: 0.28,
      heuristicScore: 0.20,
      aiReason: 'Standard road maintenance grievance requiring civil repair rather than technology innovation.',
      isAggregated: false,
      sourceProblemIds: [],
      upvotes: 5,
      downvotes: 0,
      createdAt: new Date(Date.now() - 14 * 86400000).toISOString()
    },
    {
      id: 'prob-gr-3',
      title: 'Muddy and foul-smelling tap water in Ward 12',
      description: 'For the past 2 days, drinking water from the taps in Ward 12 has been coming out dirty and brown. Please send a pipeline cleaning crew to flush the main supply line.',
      category: 'Health',
      canBeAddressed: 'No',
      locationState: 'Maharashtra',
      locationDistrict: 'Pune',
      submitterType: 'citizen',
      submitterId: 'usr-citizen-1',
      submitterName: 'Anil Joshi',
      status: 'general-grievance',
      confidence: 0.25,
      heuristicScore: 0.18,
      aiReason: 'Routine water pipeline flush and tank cleaning operational request.',
      isAggregated: false,
      sourceProblemIds: [],
      upvotes: 4,
      downvotes: 0,
      createdAt: new Date(Date.now() - 12 * 86400000).toISOString()
    },
    {
      id: 'prob-gr-4',
      title: 'Overflowing garbage bin outside Government High School',
      description: 'The municipal waste bin outside Government High School has been overflowing for 3 days. Stray animals are scattering trash. Please dispatch a garbage truck immediately.',
      category: 'Environment',
      canBeAddressed: 'No',
      locationState: 'Haryana',
      locationDistrict: 'Gurugram',
      submitterType: 'citizen',
      submitterId: 'usr-citizen-1',
      submitterName: 'Meenakshi Sundaram',
      status: 'general-grievance',
      confidence: 0.19,
      heuristicScore: 0.12,
      aiReason: 'One-off municipal garbage truck dispatch and collection request.',
      isAggregated: false,
      sourceProblemIds: [],
      upvotes: 6,
      downvotes: 0,
      createdAt: new Date(Date.now() - 11 * 86400000).toISOString()
    },
    {
      id: 'prob-gr-5',
      title: 'Electricity bill calculated incorrectly for 2-room home',
      description: 'The meter reader entered 15,000 units instead of 500 units for our small 2-room home. The billing counter is asking for formal correction. Please verify the actual meter reading.',
      category: 'Technology gap',
      canBeAddressed: 'No',
      locationState: 'Uttar Pradesh',
      locationDistrict: 'Lakhimpur',
      submitterType: 'citizen',
      submitterId: 'usr-citizen-1',
      submitterName: 'Sohan Lal',
      status: 'general-grievance',
      confidence: 0.21,
      heuristicScore: 0.14,
      aiReason: 'Individual utility billing error requiring clerical verification by the electricity board.',
      isAggregated: false,
      sourceProblemIds: [],
      upvotes: 3,
      downvotes: 0,
      createdAt: new Date(Date.now() - 9 * 86400000).toISOString()
    },
    {
      id: 'prob-gr-6',
      title: 'Blocked market drain spilling dirty water on street',
      description: 'Plastic bags have choked the market gutter line, causing dirty water to spill on the shopping street. Please send a sanitation team to unclog the drain.',
      category: 'Infrastructure',
      canBeAddressed: 'No',
      locationState: 'Maharashtra',
      locationDistrict: 'Pune',
      submitterType: 'citizen',
      submitterId: 'usr-citizen-1',
      submitterName: 'Pune Traders Association',
      status: 'general-grievance',
      confidence: 0.31,
      heuristicScore: 0.25,
      aiReason: 'Routine municipal gutter unclogging maintenance ticket.',
      isAggregated: false,
      sourceProblemIds: [],
      upvotes: 7,
      downvotes: 0,
      createdAt: new Date(Date.now() - 8 * 86400000).toISOString()
    },
    {
      id: 'prob-gr-7',
      title: 'Park bench broken and overgrown grass in Rose Garden',
      description: 'Iron benches are broken and wild bushes are overgrown in Sector 9 Rose Garden. Children cannot play. Please send a gardener and repair staff.',
      category: 'Other',
      canBeAddressed: 'No',
      locationState: 'Chandigarh',
      locationDistrict: 'Chandigarh',
      submitterType: 'citizen',
      submitterId: 'usr-citizen-1',
      submitterName: 'Ritu Kapoor',
      status: 'general-grievance',
      confidence: 0.15,
      heuristicScore: 0.10,
      aiReason: 'Routine horticulture maintenance and bench repair.',
      isAggregated: false,
      sourceProblemIds: [],
      upvotes: 1,
      downvotes: 0,
      createdAt: new Date(Date.now() - 7 * 86400000).toISOString()
    },

    // --- AGGREGATED RESEARCH PROBLEM CARD (From Pattern Aggregation Engine) ---
    {
      id: 'prob-agg-1',
      title: 'Combined Innovation Challenge: Fixing Repeated Sewer Blockages in Pune',
      description: '4 separate citizen and officer complaints were reported about dirty overflowing drains in Pune. Instead of clearing drains manually again and again, we need an underground digital mapping system to fix the root cause.',
      category: 'Infrastructure',
      canBeAddressed: 'Yes',
      locationState: 'Maharashtra',
      locationDistrict: 'Pune',
      submitterType: 'system',
      submitterId: 'system-aggregator',
      submitterName: 'System Pattern Aggregator',
      departmentName: 'Dept of Urban Infrastructure & Sewage Mgmt',
      status: 'research-worthy',
      confidence: 0.95,
      aiReason: 'Auto-generated research card created from 4 matching civic complaints. Promoted to innovation challenge due to repeated regional drain failures.',
      isAggregated: true,
      sourceProblemIds: ['prob-gr-1', 'prob-gr-2', 'prob-gr-3', 'prob-gr-6'],
      upvotes: 85,
      downvotes: 1,
      createdAt: new Date(Date.now() - 1 * 86400000).toISOString()
    }
  ];

  // Authentic Indian District Geocoordinates mapping for Live Map & Anti-Fraud GPS
  const DISTRICT_COORDS = {
    'Pune': { lat: 18.5204, lng: 73.8567 },
    'Shimla': { lat: 31.1048, lng: 77.1734 },
    'Chennai': { lat: 13.0827, lng: 80.2707 },
    'Chandrapur': { lat: 19.9615, lng: 79.2961 },
    'Malda': { lat: 25.0108, lng: 88.1411 },
    'Bengaluru': { lat: 12.9716, lng: 77.5946 },
    'Azadpur': { lat: 28.7073, lng: 77.1755 },
    'Barmer': { lat: 25.7532, lng: 71.3967 },
    'Central Delhi': { lat: 28.6448, lng: 77.2167 },
    'Ahmedabad': { lat: 23.0225, lng: 72.5714 },
    'Gurugram': { lat: 28.4595, lng: 77.0266 },
    'Lakhimpur': { lat: 27.9463, lng: 80.7786 },
    'Chandigarh': { lat: 30.7333, lng: 76.7794 }
  };

  problems.forEach((p, idx) => {
    const base = DISTRICT_COORDS[p.locationDistrict] || { lat: 18.5204, lng: 73.8567 };
    // Small natural spread jitter so markers in the same city don't completely overlap
    const jitterLat = ((idx % 7) - 3) * 0.012;
    const jitterLng = (((idx * 3) % 7) - 3) * 0.012;
    p.locationCoordinates = {
      lat: Number((base.lat + jitterLat).toFixed(6)),
      lng: Number((base.lng + jitterLng).toFixed(6)),
      accuracy: 6 + (idx % 6) * 3,
      timestamp: p.createdAt
    };
    p.locationAddress = `${p.locationDistrict}, ${p.locationState}, India`;
    p.isGpsVerified = true;
    p.gpsVerificationScore = 0.95;
  });

  // 3. Proposals
  const proposals = [
    {
      id: 'prop-1',
      problemId: 'prob-rw-1', // Flood prediction
      teamName: 'Vardhaman AI & Hydrology Lab',
      universityName: 'IIT Bombay',
      leadStudentName: 'Priya Patel',
      facultyAdvisor: 'Prof. R. V. Kulkarni (Dept of Civil & AI)',
      proposalText: 'We propose deploying solar-powered water level radar sensors along the Mula-Mutha river to alert communities and disaster officers 4 hours before flood water enters streets.',
      estimatedWeeks: 12,
      requestedFunding: 350000,
      teamMembers: ['Priya Patel (Lead)', 'Aman Verma (IoT)', 'Neha Gupta (ML Engineer)', 'Rohan Shah (GIS)'],
      status: 'approved',
      createdAt: new Date(Date.now() - 6 * 86400000).toISOString()
    },
    {
      id: 'prop-2',
      problemId: 'prob-rw-3', // Plastic Skimmer
      teamName: 'Clean Ocean Robotics',
      universityName: 'College of Engineering Pune (COEP)',
      leadStudentName: 'Siddharth Joshi',
      facultyAdvisor: 'Dr. M. S. Deshpande',
      proposalText: 'We propose building a small solar-powered floating robot boat with smart cameras to scoop and collect plastic waste from Chennai river mouths.',
      estimatedWeeks: 10,
      requestedFunding: 250000,
      teamMembers: ['Siddharth Joshi', 'Tanvi Shinde', 'Ketan Naik'],
      status: 'pending',
      createdAt: new Date(Date.now() - 4 * 86400000).toISOString()
    }
  ];

  // 4. Teams
  const teams = [
    {
      id: 'team-1',
      name: 'Vardhaman AI & Hydrology Lab',
      universityName: 'IIT Bombay',
      problemId: 'prob-rw-1',
      proposalId: 'prop-1',
      industryPartnerId: 'usr-ind-1',
      industryPartnerName: 'TechCorp Innovations & CleanTech Fund',
      committedResources: 'Grant Funding ($4000 / ₹3,50,000) + AWS Cloud GPU Credits + Radar Sensor Hardware Kit',
      mentorName: 'Anil Mehta (VP Engineering, TechCorp)',
      status: 'active',
      createdAt: new Date(Date.now() - 5 * 86400000).toISOString()
    }
  ];

  // 5. Milestones (Demonstrating Milestone-Gated Funding Release)
  const milestones = [
    {
      id: 'ms-1',
      teamId: 'team-1',
      name: 'Phase 1: Sensor Array Deployment & IoT Network Verification',
      description: 'Design and deploy 5 solar radar sensor nodes along Mula-Mutha river bank; verify LoRaWAN data telemetry pipeline.',
      targetDate: '2026-09-20',
      resourceAmount: 105000, // ₹1,05,000 (30%)
      status: 'released', // Fully reviewed and released by Industry partner
      completionNotes: 'All 5 sensor nodes fabricated and transmitting live water level telemetry at 30-second intervals.',
      releasedBy: 'Anil Mehta (TechCorp)',
      releasedAt: new Date(Date.now() - 2 * 86400000).toISOString(),
      releaseNotes: 'Telemetry verified live on dashboard. Phase 1 milestone tranche released.'
    },
    {
      id: 'ms-2',
      teamId: 'team-1',
      name: 'Phase 2: Hydrological AI Model Training & Alert Gateway Integration',
      description: 'Train TCN deep learning model on historical rainfall/water level data; integrate early warning alert SMS gateway for municipal disaster officers.',
      targetDate: '2026-10-15',
      resourceAmount: 140000, // ₹1,40,000 (40%)
      status: 'completed', // Completed by University Team -> Waiting for Industry Release button click!
      completionNotes: 'Model trained with 94.2% validation accuracy on 10-year flood records. SMS alert API tested with Pune Disaster Cell.',
      updatedAt: new Date(Date.now() - 1 * 86400000).toISOString()
    },
    {
      id: 'ms-3',
      teamId: 'team-1',
      name: 'Phase 3: Final System Integration, Handover & Government Adoption Package',
      description: 'Comprehensive 30-day continuous field pilot, user documentation, code handover, and final demo presentation to Pune Municipal Corporation.',
      targetDate: '2026-11-05',
      resourceAmount: 105000, // ₹1,05,000 (30%)
      status: 'pending'
    }
  ];

  // 6. Tasks (Kanban Board)
  const tasks = [
    {
      id: 'tsk-1',
      teamId: 'team-1',
      title: 'Calibrate radar sensor node microcontrollers',
      description: 'Ensure waterproof enclosure and solar MPPT efficiency',
      column: 'done',
      assignedTo: 'Aman Verma'
    },
    {
      id: 'tsk-2',
      teamId: 'team-1',
      title: 'Train TCN flood surge prediction model',
      description: 'Run 100 epochs on GPU cluster with historical telemetry',
      column: 'done',
      assignedTo: 'Neha Gupta'
    },
    {
      id: 'tsk-3',
      teamId: 'team-1',
      title: 'Integrate WhatsApp & SMS alert webhook',
      description: 'Connect Twilio/SMS gateway to high-water threshold trigger',
      column: 'in-progress',
      assignedTo: 'Priya Patel'
    },
    {
      id: 'tsk-4',
      teamId: 'team-1',
      title: 'Draft Municipal Disaster Dept User Manual',
      description: 'Prepare step-by-step operating guidelines for city officers',
      column: 'todo',
      assignedTo: 'Rohan Shah'
    }
  ];

  // 7. Solution Submissions
  const solutionSubmissions = [
    {
      id: 'sol-1',
      teamId: 'team-1',
      problemId: 'prob-rw-1',
      summary: 'Developed and field-validated the Vardhaman River-AI Flood Early Warning System. Deployed 5 LoRaWAN solar radar nodes along the river basin delivering 4-hour advance crest notifications with 94.2% predictive precision.',
      artifactsUrl: 'https://github.com/iitb-vardhaman/mula-mutha-flood-ai',
      demoUrl: 'https://mula-mutha-flood-ai.demo.iitb.ac.in',
      submittedAt: new Date(Date.now() - 1 * 86400000).toISOString(),
      adoptedByGovId: 'usr-govt-1',
      adoptedDepartment: 'Department of Urban Infrastructure & Water Resources',
      adoptedAt: new Date().toISOString(),
      adoptionNotes: 'Officially adopted for permanent integration into Pune City Smart Disaster Response System.'
    }
  ];

  // 8. Aggregation Job Logs
  const aggregationLogs = [
    {
      id: 'log-1',
      timestamp: new Date(Date.now() - 1 * 86400000).toISOString(),
      candidatesEvaluated: 11,
      clustersCreated: 1,
      thresholdUsed: 3,
      createdProblemIds: ['prob-agg-1'],
      status: 'success'
    }
  ];

  const dbState = {
    users,
    problems,
    votes: [],
    teams,
    proposals,
    milestones,
    tasks,
    solutionSubmissions,
    aggregationLogs
  };

  resetDB(dbState);
  console.log('[Seed] Database seeded successfully with 20 realistic problems and full test workspace.');
}

if (require.main === module) {
  seedDatabase();
}

module.exports = { seedDatabase };
