const express = require('express');
const router = express.Router();
const { getDB, saveDB, generateId } = require('../db/store');
const { classifyProblem, analyzeAndExtractProblem } = require('../services/classifier');

const MAX_WEEKLY_REPORTS = 4;
const ROLLING_WINDOW_MS = 7 * 24 * 60 * 60 * 1000; // 7 days rolling window

/**
 * Calculate rate-limit quota and rolling 7-day window for citizens.
 * Government, Industry, University, and Admin roles are 100% exempt with unlimited submissions.
 */
function calculateCitizenQuota({ submitterId, submitterType, clientIp, reportedProblemIds = [] }) {
  const normalizedType = (submitterType || '').toLowerCase();
  
  // Role Exemption: Government, Industry, University, and Admin have unlimited submissions
  if (
    normalizedType === 'government' || 
    normalizedType === 'industry' || 
    normalizedType === 'admin' || 
    normalizedType === 'university'
  ) {
    return {
      isExempt: true,
      role: normalizedType,
      maxAllowed: 'unlimited',
      used: 0,
      remaining: 9999,
      canSubmit: true,
      timerActive: false,
      windowStart: null,
      resetAt: null,
      resetInMs: 0,
      message: 'Unlimited Priority Submissions (Verified Organization)'
    };
  }

  const db = getDB();
  const allProblems = db.problems || [];
  const now = Date.now();
  const windowBoundary = now - ROLLING_WINDOW_MS;

  const localIdSet = new Set(
    Array.isArray(reportedProblemIds) 
      ? reportedProblemIds 
      : (typeof reportedProblemIds === 'string' ? reportedProblemIds.split(',').map(s => s.trim()) : [])
  );

  const isLoopback = (ip) => !ip || ip === '127.0.0.1' || ip === '::1' || ip.startsWith('::ffff:127.0.0.1') || ip === 'localhost';

  // Filter problems submitted by this citizen
  const citizenSubmissions = allProblems.filter(p => {
    const pType = (p.submitterType || 'citizen').toLowerCase();
    if (pType !== 'citizen' && pType !== 'anonymous') return false;

    // 1. If authenticated user ID provided, track strictly by user ID
    if (submitterId && submitterId !== 'anonymous' && submitterId !== 'anonymous-user') {
      return p.submitterId === submitterId;
    }

    // 2. Otherwise for anonymous, track by local storage submission IDs or public IP
    const isSameLocalId = p.id && localIdSet.has(p.id);
    const isSameIp = !isLoopback(clientIp) && p.clientIp === clientIp;

    return isSameLocalId || isSameIp;
  });

  // Filter problems created inside the active 7-day rolling window
  const activeSubmissions = citizenSubmissions
    .map(p => ({
      id: p.id,
      title: p.title,
      createdAt: p.createdAt,
      time: new Date(p.createdAt || now).getTime()
    }))
    .filter(p => p.time >= windowBoundary)
    .sort((a, b) => a.time - b.time); // Oldest first

  const used = activeSubmissions.length;
  const remaining = Math.max(0, MAX_WEEKLY_REPORTS - used);
  const canSubmit = remaining > 0;

  let timerActive = false;
  let windowStart = null;
  let resetAt = null;
  let resetInMs = 0;

  if (activeSubmissions.length > 0) {
    timerActive = true;
    // Window started on the citizen's 1st submission in the period
    windowStart = new Date(activeSubmissions[0].time).toISOString();
    // 7-day timer expires exactly 7 days after the first submission
    const resetTime = activeSubmissions[0].time + ROLLING_WINDOW_MS;
    resetAt = new Date(resetTime).toISOString();
    resetInMs = Math.max(0, resetTime - now);
  }

  return {
    isExempt: false,
    role: 'citizen',
    maxAllowed: MAX_WEEKLY_REPORTS,
    used,
    remaining,
    canSubmit,
    timerActive,
    windowStart,
    resetAt,
    resetInMs,
    submissionsInWindow: activeSubmissions.length
  };
}

/**
 * GET /api/problems/quota
 * Query active rate-limit status, remaining weekly submissions, and reset countdown
 */
router.get('/quota', (req, res) => {
  try {
    const { submitterId, submitterType, ids } = req.query;
    const clientIp = req.headers['x-forwarded-for'] || req.socket.remoteAddress || '127.0.0.1';
    const parsedClientIp = typeof clientIp === 'string' ? clientIp.split(',')[0].trim() : '127.0.0.1';
    const reportedProblemIds = ids ? ids.split(',').map(s => s.trim()) : [];

    const quota = calculateCitizenQuota({
      submitterId,
      submitterType: submitterType || (submitterId && submitterId !== 'anonymous' ? 'citizen' : 'anonymous'),
      clientIp: parsedClientIp,
      reportedProblemIds
    });

    res.json(quota);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * AI Auto-Detect & Extract Problem Metadata
 * Analyzes raw description to auto-generate title, sector, solution type, and feasibility
 */
router.post('/analyze', async (req, res) => {
  try {
    const { description, title, category } = req.body;
    if (!description || !description.trim()) {
      return res.status(400).json({ error: 'Description is required for AI analysis.' });
    }

    const analysis = await analyzeAndExtractProblem(description.trim(), title, category);
    res.json(analysis);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Submit Problem with Structured Form & AI Classification Pipeline
 */
router.post('/submit', async (req, res) => {
  try {
    const {
      title,
      description,
      category,
      canBeAddressed,
      locationState,
      locationDistrict,
      locationCoordinates,
      locationAddress,
      isGpsVerified,
      deviceMetadata,
      submitterType, // 'citizen' or 'government' or 'industry'
      submitterId,
      submitterName,
      departmentName,
      attachmentUrl,
      reportedProblemIds
    } = req.body;

    if (!description || !description.trim()) {
      return res.status(400).json({ error: 'Problem description is required.' });
    }

    // MANDATORY GPS LOCATION ENFORCEMENT (Anti-Fraud & Anti-Spam Gate)
    const latNum = locationCoordinates ? Number(locationCoordinates.lat) : NaN;
    const lngNum = locationCoordinates ? Number(locationCoordinates.lng) : NaN;

    if (
      !locationCoordinates || 
      isNaN(latNum) || 
      isNaN(lngNum) ||
      latNum < -90 || latNum > 90 ||
      lngNum < -180 || lngNum > 180
    ) {
      return res.status(400).json({
        error: 'Mandatory GPS Location Missing: In order to eliminate spam and prevent fake civic reports, real-time device location verification is strictly mandatory. Please allow location access to proceed.',
        requiresLocation: true
      });
    }

    // RATE LIMITING & QUOTA SAFEGUARD (Citizens limited to 4 per 7 days; Gov/Industry unlimited)
    const clientIp = req.headers['x-forwarded-for'] || req.socket.remoteAddress || '127.0.0.1';
    const parsedClientIp = typeof clientIp === 'string' ? clientIp.split(',')[0].trim() : '127.0.0.1';

    const quota = calculateCitizenQuota({
      submitterId,
      submitterType,
      clientIp: parsedClientIp,
      reportedProblemIds: reportedProblemIds || []
    });

    if (!quota.canSubmit) {
      const resetDateStr = quota.resetAt ? new Date(quota.resetAt).toLocaleString('en-IN', {
        timeZone: 'Asia/Kolkata',
        dateStyle: 'medium',
        timeStyle: 'short'
      }) : 'in a few days';

      return res.status(429).json({
        error: `Weekly Submission Limit Reached: Anti-spam policy limits citizens to ${quota.maxAllowed} reports per 7-day window. Your quota unlocks on ${resetDateStr}. Government and industry partners have unlimited submissions.`,
        limitReached: true,
        quota
      });
    }

    // Run classification & extraction pipeline
    const classification = await classifyProblem(title || '', description.trim(), category, {
      techSolvable: canBeAddressed
    });

    // Reject spam, joke, or invalid test submissions
    if (classification.status === 'spam-rejected') {
      return res.status(400).json({
        error: classification.aiReason || 'Submission flagged as invalid test text or joke.',
        isSpam: true,
        classification
      });
    }

    const db = getDB();
    const problemId = generateId();

    const finalTitle = (title && title.trim().length >= 4) 
      ? title.trim() 
      : (classification.suggestedTitle || 'Civic Innovation Challenge');

    const finalCategory = (category && category !== 'Not sure' && category !== 'Other')
      ? category
      : (classification.category || 'Infrastructure');

    const accuracy = Number(locationCoordinates.accuracy) || 10;
    const gpsScore = accuracy <= 20 ? 0.98 : accuracy <= 100 ? 0.90 : 0.80;

    const newProblem = {
      id: problemId,
      title: finalTitle,
      description: description.trim(),
      category: finalCategory,
      solutionType: classification.solutionType || 'not-sure',
      solutionTypeLabel: classification.solutionTypeLabel || 'General Problem',
      problemType: classification.problemType || (classification.status === 'research-worthy' ? 'research' : classification.status === 'general-grievance' ? 'execution' : 'review'),
      problemTypeLabel: classification.problemTypeLabel || (classification.status === 'research-worthy' ? 'Research Problem (R&D)' : classification.status === 'general-grievance' ? 'Execution Grievance (Civic Maintenance)' : 'Under Review'),
      statusLabel: classification.statusLabel || (classification.status === 'research-worthy' ? 'Research-Worthy Problem (R&D Innovation)' : 'Operational Execution Grievance'),
      keyTechnologies: classification.keyTechnologies || [],
      canBeAddressed: canBeAddressed || 'Not sure',
      locationState: locationState || 'All India',
      locationDistrict: locationDistrict || 'General',
      locationCoordinates: {
        lat: Number(locationCoordinates.lat),
        lng: Number(locationCoordinates.lng),
        accuracy: accuracy,
        timestamp: locationCoordinates.timestamp || new Date().toISOString()
      },
      locationAddress: locationAddress || `${locationDistrict || 'Local Area'}, ${locationState || 'India'}`,
      isGpsVerified: true,
      gpsVerificationScore: gpsScore,
      clientIp: typeof clientIp === 'string' ? clientIp.split(',')[0].trim() : '127.0.0.1',
      deviceMetadata: deviceMetadata || {},
      submitterType: submitterType || 'citizen',
      submitterId: submitterId || 'anonymous-user',
      submitterName: submitterName || 'Civic Submitter',
      departmentName: departmentName || (submitterType === 'government' ? 'Dept of Urban Infrastructure' : ''),
      attachmentUrl: attachmentUrl || '',
      status: classification.status, // 'research-worthy' | 'needs-review' | 'general-grievance'
      confidence: classification.confidence,
      heuristicScore: classification.heuristicScore,
      aiReason: classification.aiReason,
      auditLog: classification.auditLog,
      isAggregated: false,
      sourceProblemIds: [],
      aggregatedIntoId: null,
      upvotes: 1,
      downvotes: 0,
      createdAt: new Date().toISOString()
    };

    db.problems.unshift(newProblem);
    saveDB();

    // Return the updated quota in response
    const updatedQuota = calculateCitizenQuota({
      submitterId,
      submitterType,
      clientIp: parsedClientIp,
      reportedProblemIds: [...(reportedProblemIds || []), problemId]
    });

    res.json({
      message: 'Problem submitted and classified successfully',
      problem: newProblem,
      classification,
      quota: updatedQuota
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Get Impact & Leaderboard Public Metrics
 */
router.get('/impact', (req, res) => {
  try {
    const db = getDB();
    const problems = db.problems || [];
    const proposals = db.proposals || [];
    const teams = db.teams || [];
    const solutions = db.solutionSubmissions || [];

    const totalProblems = problems.length;
    const totalResearch = problems.filter(p => p.status === 'research-worthy').length;
    const totalAdopted = solutions.filter(s => s.adoptedByGovId).length;
    const totalFundingAllocated = proposals
      .filter(pr => pr.status === 'approved')
      .reduce((sum, pr) => sum + (pr.requestedFunding || 0), 0);

    // Base Top University Leaderboard
    const defaultUniversities = [
      {
        name: "IIT Bombay - Innovation & Clean Energy Center",
        solvedCount: 3,
        activeProjects: 4,
        fundingReceived: 1450000,
        solvedProblems: [
          { id: "p-1", title: "Smart Flood Warning System for River Areas", category: "Water & Sanitation", isAdopted: true },
          { id: "p-2", title: "Solar Power Optimization for Village Sub-Stations", category: "Energy", isAdopted: true },
          { id: "p-3", title: "Smart Stormwater Early Warning System", category: "Infrastructure", isAdopted: true }
        ]
      },
      {
        name: "IISc Bangalore - Smart Infrastructure & Environment Lab",
        solvedCount: 2,
        activeProjects: 3,
        fundingReceived: 1280000,
        solvedProblems: [
          { id: "p-4", title: "Automated Waste Sorting Machine", category: "Environment", isAdopted: true },
          { id: "p-5", title: "Road Pothole AI Detection from City Buses", category: "Infrastructure", isAdopted: true }
        ]
      },
      {
        name: "IIT Madras - Water Technology & Environmental Research Lab",
        solvedCount: 2,
        activeProjects: 3,
        fundingReceived: 1120000,
        solvedProblems: [
          { id: "p-6", title: "Low-Cost Saltwater Filter for Coastal Wells", category: "Water & Sanitation", isAdopted: true },
          { id: "p-7", title: "Drain Pipe Inspection Robot for Poisonous Gases", category: "Public Health", isAdopted: true }
        ]
      },
      {
        name: "COEP Technological University (College of Engineering Pune)",
        solvedCount: 2,
        activeProjects: 2,
        fundingReceived: 950000,
        solvedProblems: [
          { id: "p-8", title: "Turning Sugarcane Farm Waste into Clean Energy", category: "Agriculture", isAdopted: true },
          { id: "p-9", title: "Smart Camera Traffic Lights to Reduce Traffic Jams", category: "Infrastructure", isAdopted: false }
        ]
      },
      {
        name: "VJTI Technological Institute Mumbai - AI & Urban Mobility Hub",
        solvedCount: 1,
        activeProjects: 3,
        fundingReceived: 820000,
        solvedProblems: [
          { id: "p-10", title: "Computer Vision Traffic Flow Optimization at High-Density Junctions", category: "Mobility", isAdopted: true }
        ]
      },
      {
        name: "IIT Delhi - Clean Air & Aerosol Dynamics Center",
        solvedCount: 1,
        activeProjects: 2,
        fundingReceived: 750000,
        solvedProblems: [
          { id: "p-11", title: "Low-Cost Smog Tower Air Filtration & Electrostatic Precipitator", category: "Environment", isAdopted: true }
        ]
      }
    ];

    const univMap = {};
    defaultUniversities.forEach(u => {
      univMap[u.name] = { ...u, solvedProblems: [...u.solvedProblems] };
    });

    proposals.forEach(prop => {
      const uName = prop.universityName || 'Partner Engineering Institute';
      if (!univMap[uName]) {
        univMap[uName] = {
          name: uName,
          solvedCount: 0,
          activeProjects: 0,
          fundingReceived: 0,
          solvedProblems: []
        };
      }
      if (prop.status === 'approved') {
        univMap[uName].activeProjects += 1;
        univMap[uName].fundingReceived += (prop.requestedFunding || 0);
      }
    });

    solutions.forEach(sol => {
      const prob = problems.find(p => p.id === sol.problemId);
      const team = teams.find(t => t.problemId === sol.problemId);
      if (prob) {
        const uName = team?.universityName || 'IIT Bombay - Innovation & Clean Energy Center';
        if (!univMap[uName]) {
          univMap[uName] = { name: uName, solvedCount: 0, activeProjects: 0, fundingReceived: 0, solvedProblems: [] };
        }
        if (!univMap[uName].solvedProblems.some(sp => sp.id === prob.id)) {
          univMap[uName].solvedCount += 1;
          univMap[uName].solvedProblems.push({
            id: prob.id,
            title: prob.title,
            category: prob.category,
            isAdopted: Boolean(sol.adoptedByGovId)
          });
        }
      }
    });

    let universityLeaderboard = Object.values(univMap);
    universityLeaderboard.sort((a, b) => b.solvedCount - a.solvedCount || b.activeProjects - a.activeProjects);

    const industryLeaderboard = [
      {
        name: "Tata Consulting Engineers - Civic Tech Division",
        milestonesFunded: 8,
        activeAdvisoryProjects: 4,
        totalContribution: "₹ 24,00,000",
        focusArea: "Urban Infrastructure, Clean Water & Smart Cities"
      },
      {
        name: "Reliance Foundation Energy & Sustainability Research",
        milestonesFunded: 6,
        activeAdvisoryProjects: 3,
        totalContribution: "₹ 18,50,000",
        focusArea: "Renewable Energy, Grid Microgrids & Solar"
      },
      {
        name: "Infosys Science Foundation - AI & Robotics Research",
        milestonesFunded: 5,
        activeAdvisoryProjects: 3,
        totalContribution: "₹ 16,00,000",
        focusArea: "AI for Governance, Smart Mobility & Computer Vision"
      },
      {
        name: "L&T Technology Services - Heavy Engineering CSR R&D",
        milestonesFunded: 4,
        activeAdvisoryProjects: 2,
        totalContribution: "₹ 12,50,000",
        focusArea: "Structural Health Monitoring & Bridge Safety"
      },
      {
        name: "Mahindra & Mahindra CSR Innovation Cell",
        milestonesFunded: 4,
        activeAdvisoryProjects: 2,
        totalContribution: "₹ 10,00,000",
        focusArea: "Agritech, EV Charging Infrastructure & Soil Sensors"
      },
      {
        name: "Wipro Cares Tech & Social Impact Fund",
        milestonesFunded: 3,
        activeAdvisoryProjects: 2,
        totalContribution: "₹ 8,50,000",
        focusArea: "Waste Management & E-Waste Tracking Protocols"
      }
    ];

    res.json({
      stats: {
        totalProblems,
        totalResearch,
        totalAdopted,
        totalFundingAllocated
      },
      universityLeaderboard,
      industryLeaderboard
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Get Public Problem Feed (Approved Research-Worthy Problems)
 */
router.get(['/', '/feed'], (req, res) => {
  try {
    const { category, state, search, submitterType } = req.query;
    const db = getDB();

    let list = db.problems.filter(p => p.status === 'research-worthy');

    if (category && category !== 'All') {
      list = list.filter(p => p.category === category);
    }

    if (state && state !== 'All') {
      list = list.filter(p => p.locationState === state);
    }

    if (submitterType && submitterType !== 'All') {
      list = list.filter(p => p.submitterType === submitterType);
    }

    if (search) {
      const q = search.toLowerCase();
      list = list.filter(p => 
        p.title.toLowerCase().includes(q) || 
        p.description.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q)
      );
    }

    // Attach active team / proposal count metadata
    const feed = list.map(p => {
      const team = db.teams.find(t => t.problemId === p.id);
      const proposalCount = db.proposals.filter(pr => pr.problemId === p.id).length;
      return {
        ...p,
        activeTeam: team || null,
        proposalCount
      };
    });

    res.json({ count: feed.length, problems: feed });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Get Needs-Review Queue (Community & Government Review Queue)
 */
router.get('/needs-review', (req, res) => {
  try {
    const db = getDB();
    const list = db.problems.filter(p => p.status === 'needs-review');
    res.json({ count: list.length, problems: list });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Get Citizen "My Submissions"
 */
router.get('/my-submissions', (req, res) => {
  try {
    const { userId, ids, email } = req.query;
    const db = getDB();

    const targetUserId = userId || 'usr-citizen-1';
    let idList = [];
    if (ids) {
      idList = ids.split(',').map(s => s.trim()).filter(Boolean);
    }

    const submissions = db.problems.filter(p => 
      p.submitterId === targetUserId || 
      (userId && p.submitterId === userId) ||
      (email && p.submitterEmail === email) ||
      idList.includes(p.id)
    );

    // Map end-to-end status tracking
    const tracked = submissions.map(p => {
      const team = db.teams.find(t => t.problemId === p.id);
      const solution = db.solutionSubmissions.find(s => s.problemId === p.id);

      let step = 1; // Submitted & Classified
      let stepLabel = 'Submitted & Validated';

      if (p.status === 'general-grievance') {
        stepLabel = 'Redirected to Local Grievance Cell';
      } else if (p.status === 'needs-review') {
        stepLabel = 'Under Community / Official Review';
      } else if (p.status === 'research-worthy') {
        if (solution && solution.adoptedByGovId) {
          step = 5;
          stepLabel = 'Solution Adopted by Government';
        } else if (solution) {
          step = 4;
          stepLabel = 'Solution Submitted - Pending Adoption';
        } else if (team) {
          step = 3;
          stepLabel = `Research Team Assigned (${team.name})`;
        } else {
          step = 2;
          stepLabel = 'Approved for Research (Open for Proposals)';
        }
      }

      return {
        ...p,
        trackingStep: step,
        trackingLabel: stepLabel,
        activeTeam: team || null,
        solutionSubmission: solution || null
      };
    });

    res.json({ count: tracked.length, submissions: tracked });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Get Government "Department Challenges & Submissions"
 */
router.get('/govt-submissions', (req, res) => {
  try {
    const { userId, department, ids } = req.query;
    const db = getDB();

    let idList = [];
    if (ids) {
      idList = ids.split(',').map(s => s.trim()).filter(Boolean);
    }

    const submissions = db.problems.filter(p => 
      p.submitterType === 'government' ||
      (userId && p.submitterId === userId) ||
      (department && p.departmentName && p.departmentName.toLowerCase().includes(department.toLowerCase())) ||
      idList.includes(p.id)
    );

    const tracked = submissions.map(p => {
      const team = db.teams.find(t => t.problemId === p.id);
      const proposals = db.proposals.filter(pr => pr.problemId === p.id);
      const solution = db.solutionSubmissions.find(s => s.problemId === p.id);
      return {
        ...p,
        activeTeam: team || null,
        proposalsCount: proposals.length,
        solutionSubmission: solution || null
      };
    });

    res.json({ count: tracked.length, submissions: tracked });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Get Problem Detail by ID
 */
router.get('/:id', (req, res) => {
  try {
    const { id } = req.params;
    const db = getDB();

    const problem = db.problems.find(p => p.id === id);
    if (!problem) {
      return res.status(404).json({ error: 'Problem not found' });
    }

    // Source problems if aggregated
    let sourceProblems = [];
    if (problem.isAggregated && problem.sourceProblemIds && problem.sourceProblemIds.length > 0) {
      sourceProblems = db.problems.filter(p => problem.sourceProblemIds.includes(p.id));
    }

    // Proposals & Team
    const proposals = db.proposals.filter(pr => pr.problemId === id);
    const activeTeam = db.teams.find(t => t.problemId === id);
    const solution = db.solutionSubmissions.find(s => s.problemId === id);

    res.json({
      problem,
      sourceProblems,
      proposals,
      activeTeam: activeTeam || null,
      solutionSubmission: solution || null
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Vote on a Problem (Upvote / Downvote)
 */
router.post('/:id/vote', (req, res) => {
  try {
    const { id } = req.params;
    const { userId, value } = req.body; // value: 1 (upvote) or -1 (downvote)

    const db = getDB();
    const problem = db.problems.find(p => p.id === id);

    if (!problem) {
      return res.status(404).json({ error: 'Problem not found' });
    }

    // Track vote
    let existingVote = db.votes.find(v => v.problemId === id && v.userId === userId);
    if (existingVote) {
      if (existingVote.value === value) {
        return res.json({ message: 'Vote already recorded', problem });
      }
      // Revert previous vote impact
      if (existingVote.value === 1) problem.upvotes = Math.max(0, problem.upvotes - 1);
      if (existingVote.value === -1) problem.downvotes = Math.max(0, problem.downvotes - 1);
      existingVote.value = value;
    } else {
      db.votes.push({
        id: generateId(),
        problemId: id,
        userId: userId || 'anonymous',
        value,
        createdAt: new Date().toISOString()
      });
    }

    if (value === 1) problem.upvotes += 1;
    if (value === -1) problem.downvotes += 1;

    // Adjust confidence & status for needs-review problems based on community consensus
    if (problem.status === 'needs-review') {
      const netVotes = problem.upvotes - problem.downvotes;
      if (netVotes >= 5) {
        problem.confidence = Math.min(0.95, problem.confidence + 0.15);
        problem.status = 'research-worthy';
        problem.aiReason += ' [Elevated to research-worthy by positive community review consensus.]';
      } else if (netVotes <= -3) {
        problem.confidence = Math.max(0.10, problem.confidence - 0.20);
        problem.status = 'general-grievance';
        problem.aiReason += ' [Reclassified as general grievance following community review.]';
      }
    }

    saveDB();
    res.json({ message: 'Vote recorded', problem });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Government Official Override Status
 */
router.post('/:id/override', (req, res) => {
  try {
    const { id } = req.params;
    const { newStatus, reviewerName, reviewNotes } = req.body; // newStatus: 'research-worthy' | 'general-grievance'

    const db = getDB();
    const problem = db.problems.find(p => p.id === id);

    if (!problem) {
      return res.status(404).json({ error: 'Problem not found' });
    }

    problem.status = newStatus;
    problem.aiReason += ` [Overridden by Government Official (${reviewerName || 'Official'}): ${reviewNotes || 'Manual validation'}]`;
    problem.overrideBy = reviewerName || 'Govt Official';
    problem.overrideAt = new Date().toISOString();

    saveDB();
    res.json({ message: `Status updated to ${newStatus}`, problem });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
