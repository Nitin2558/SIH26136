const express = require('express');
const router = express.Router();
const { getDB, saveDB } = require('../db/store');
const { runPatternAggregation } = require('../services/aggregator');

/**
 * Get Users
 */
router.get('/users', (req, res) => {
  try {
    const db = getDB();
    const sanitized = db.users.map(({ passwordHash, ...user }) => user);
    res.json({ users: sanitized });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Get Platform Stats
 */
router.get('/stats', (req, res) => {
  try {
    const db = getDB();
    const totalProblems = db.problems.length;
    const researchWorthy = db.problems.filter(p => p.status === 'research-worthy').length;
    const generalGrievances = db.problems.filter(p => p.status === 'general-grievance').length;
    const needsReview = db.problems.filter(p => p.status === 'needs-review').length;
    const aggregated = db.problems.filter(p => p.isAggregated).length;
    const activeTeams = db.teams.length;
    const solutionsAdopted = db.solutionSubmissions.filter(s => s.adoptedByGovId !== null).length;

    res.json({
      totalProblems,
      researchWorthy,
      generalGrievances,
      needsReview,
      aggregated,
      activeTeams,
      solutionsAdopted
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Trigger Pattern Aggregation Pass
 */
router.post('/aggregate', (req, res) => {
  try {
    const { threshold } = req.body;
    const log = runPatternAggregation(threshold ? parseInt(threshold, 10) : 3);
    res.json({ message: 'Pattern aggregation job completed', log });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Get Aggregation Job Logs
 */
router.get('/aggregation-logs', (req, res) => {
  try {
    const db = getDB();
    res.json({ logs: db.aggregationLogs || [] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
