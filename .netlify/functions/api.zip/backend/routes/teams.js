const express = require('express');
const router = express.Router();
const { getDB, saveDB, generateId } = require('../db/store');

/**
 * Submit Proposal (University Team)
 */
router.post('/apply', (req, res) => {
  try {
    const {
      problemId,
      teamName,
      universityName,
      leadStudentName,
      facultyAdvisor,
      proposalText,
      estimatedWeeks,
      requestedFunding,
      teamMembers
    } = req.body;

    if (!problemId || !teamName || !universityName || !proposalText) {
      return res.status(400).json({ error: 'Problem ID, team name, university name, and proposal text are required.' });
    }

    const db = getDB();
    const problem = db.problems.find(p => p.id === problemId);
    if (!problem) {
      return res.status(404).json({ error: 'Problem not found' });
    }

    const newProposal = {
      id: generateId(),
      problemId,
      teamName,
      universityName,
      leadStudentName: leadStudentName || 'Team Lead',
      facultyAdvisor: facultyAdvisor || 'Faculty Advisor',
      proposalText,
      estimatedWeeks: estimatedWeeks || 8,
      requestedFunding: requestedFunding || 100000,
      teamMembers: teamMembers || [],
      status: 'pending', // 'pending' | 'approved' | 'rejected'
      createdAt: new Date().toISOString()
    };

    db.proposals.push(newProposal);
    saveDB();

    res.json({ message: 'Proposal submitted successfully', proposal: newProposal });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Get Proposals for a Problem
 */
router.get('/proposals', (req, res) => {
  try {
    const { problemId, universityName } = req.query;
    const db = getDB();

    let list = db.proposals;
    if (problemId) {
      list = list.filter(pr => pr.problemId === problemId);
    }
    if (universityName) {
      list = list.filter(pr => pr.universityName === universityName);
    }

    res.json({ proposals: list });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Get All Active University Research Projects (Industry R&D Scouting Catalog)
 */
router.get('/active-projects', (req, res) => {
  try {
    const db = getDB();
    const teams = db.teams || [];
    const problems = db.problems || [];
    const proposals = db.proposals || [];
    const milestones = db.milestones || [];
    const evidence = db.researchEvidence || [];

    const list = teams.map(t => {
      const prob = problems.find(p => p.id === t.problemId);
      const prop = proposals.find(pr => pr.id === t.proposalId);
      const teamMs = milestones.filter(m => m.teamId === t.id);
      const completedMs = teamMs.filter(m => m.status === 'completed' || m.status === 'released').length;
      
      const teamEvid = evidence.filter(e => (e.universityName || '').toLowerCase() === (t.universityName || '').toLowerCase());
      const maxStage = teamEvid[0]?.progressStage || (completedMs >= 2 ? 'PILOT' : completedMs >= 1 ? 'PROTOTYPE' : 'RESEARCH');
      const maxPct = teamEvid[0]?.progressPercentage || (completedMs === 3 ? 100 : completedMs === 2 ? 75 : completedMs === 1 ? 40 : 20);

      return {
        id: t.id,
        name: t.name,
        universityName: t.universityName || 'Partner Engineering Institute',
        problemId: t.problemId,
        problemTitle: prob?.title || 'Civic Technology Research Challenge',
        category: prob?.category || 'Technology gap',
        locationState: prob?.locationState || 'All India',
        proposalId: t.proposalId,
        requestedFunding: prop?.requestedFunding || 500000,
        leadStudentName: prop?.leadStudentName || 'Student Research Lead',
        facultyAdvisor: prop?.facultyAdvisor || 'Faculty Research Advisor',
        industryPartnerId: t.industryPartnerId,
        industryPartnerName: t.industryPartnerName,
        isSponsored: Boolean(t.industryPartnerName),
        milestonesTotal: teamMs.length || 3,
        milestonesCompleted: completedMs,
        progressStage: maxStage,
        progressPercentage: maxPct,
        createdAt: t.createdAt
      };
    });

    let projects = list;
    if (projects.length === 0) {
      projects = [
        {
          id: "team-1",
          name: "Vardhaman River AI Sensing Team",
          universityName: "IIT Bombay",
          problemId: "prob-rw-1",
          problemTitle: "AI Edge Computer Vision for Solar Microgrid Optimization",
          category: "Energy",
          locationState: "Maharashtra",
          proposalId: "prop-1",
          requestedFunding: 500000,
          leadStudentName: "Priya Patel",
          facultyAdvisor: "Prof. A. K. Sharma",
          industryPartnerId: "ind-1",
          industryPartnerName: "Tata Consulting Engineers",
          isSponsored: true,
          milestonesTotal: 3,
          milestonesCompleted: 2,
          progressStage: "PILOT",
          progressPercentage: 75,
          createdAt: new Date().toISOString()
        },
        {
          id: "team-2",
          name: "VJTI IoT Flood Telemetry Lab",
          universityName: "VJTI Technological Institute",
          problemId: "prob-rw-2",
          problemTitle: "IoT Radar Sensor Flood Crest Warning Pipeline",
          category: "Infrastructure",
          locationState: "Karnataka",
          proposalId: "prop-2",
          requestedFunding: 450000,
          leadStudentName: "Rohan Verma",
          facultyAdvisor: "Prof. S. R. Kulkarni",
          industryPartnerId: null,
          industryPartnerName: null,
          isSponsored: false,
          milestonesTotal: 3,
          milestonesCompleted: 1,
          progressStage: "PROTOTYPE",
          progressPercentage: 45,
          createdAt: new Date().toISOString()
        },
        {
          id: "team-3",
          name: "COEP Clean Water Bio-Filter Team",
          universityName: "COEP Technological University",
          problemId: "prob-rw-3",
          problemTitle: "Biotech Nanocomposite Water Purification Unit",
          category: "Water & Sanitation",
          locationState: "Gujarat",
          proposalId: "prop-3",
          requestedFunding: 600000,
          leadStudentName: "Ananya Deshmukh",
          facultyAdvisor: "Dr. V. M. Joshi",
          industryPartnerId: "ind-2",
          industryPartnerName: "Reliance Foundation",
          isSponsored: true,
          milestonesTotal: 3,
          milestonesCompleted: 3,
          progressStage: "COMPLETED",
          progressPercentage: 100,
          createdAt: new Date().toISOString()
        }
      ];
    }

    res.json({ count: projects.length, projects });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Approve Proposal -> Create Active Team & Initialize Workspace (Milestones & Kanban Tasks)
 */
router.post('/approve-proposal', (req, res) => {
  try {
    const { proposalId } = req.body;
    const db = getDB();

    const proposal = db.proposals.find(pr => pr.id === proposalId);
    if (!proposal) {
      return res.status(404).json({ error: 'Proposal not found' });
    }

    proposal.status = 'approved';

    // Check if team already exists for this problem
    let team = db.teams.find(t => t.problemId === proposal.problemId);
    if (!team) {
      const teamId = generateId();
      team = {
        id: teamId,
        name: proposal.teamName,
        universityName: proposal.universityName,
        problemId: proposal.problemId,
        proposalId: proposal.id,
        industryPartnerId: null,
        industryPartnerName: null,
        status: 'active',
        createdAt: new Date().toISOString()
      };
      db.teams.push(team);

      // Create Initial Default Milestones
      const m1Id = generateId();
      const m2Id = generateId();
      const m3Id = generateId();

      db.milestones.push(
        {
          id: m1Id,
          teamId,
          name: 'Phase 1: Requirements & Architectural Prototype',
          description: 'Detailed technical specification, baseline hardware/software architecture design, and initial proof-of-concept.',
          targetDate: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
          resourceAmount: Math.round(proposal.requestedFunding * 0.30),
          status: 'in-progress' // 'pending' | 'in-progress' | 'completed' | 'released'
        },
        {
          id: m2Id,
          teamId,
          name: 'Phase 2: Core Engineering & Field Pilot Testing',
          description: 'Deploy working prototype in target region, run pilot diagnostic tests, gather performance metrics.',
          targetDate: new Date(Date.now() + 35 * 86400000).toISOString().split('T')[0],
          resourceAmount: Math.round(proposal.requestedFunding * 0.40),
          status: 'pending'
        },
        {
          id: m3Id,
          teamId,
          name: 'Phase 3: Final Deployment & Package Handover',
          description: 'Complete system optimization, documentation, code repositories, demo links, and government adoption package.',
          targetDate: new Date(Date.now() + 56 * 86400000).toISOString().split('T')[0],
          resourceAmount: Math.round(proposal.requestedFunding * 0.30),
          status: 'pending'
        }
      );

      // Create Starter Kanban Tasks
      db.tasks.push(
        {
          id: generateId(),
          teamId,
          title: 'Conduct initial field site survey',
          description: 'Gather localized sensor inputs & baseline dataset',
          column: 'done', // 'todo' | 'in-progress' | 'review' | 'done'
          assignedTo: proposal.leadStudentName
        },
        {
          id: generateId(),
          teamId,
          title: 'Build initial AI model / system workflow',
          description: 'Develop prototype code repository and API endpoints',
          column: 'in-progress',
          assignedTo: proposal.teamName
        },
        {
          id: generateId(),
          teamId,
          title: 'Integrate hardware / cloud infrastructure',
          description: 'Setup continuous monitoring and data pipeline',
          column: 'todo',
          assignedTo: 'Team Member'
        }
      );
    }

    saveDB();
    res.json({ message: 'Proposal approved and project workspace created', team, proposal });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Industry Partner Attach to Team
 */
router.post('/:id/attach-industry', (req, res) => {
  try {
    const { id } = req.params; // teamId
    const { industryPartnerId, industryPartnerName, committedResources, mentorName } = req.body;

    const db = getDB();
    const team = db.teams.find(t => t.id === id);

    if (!team) {
      return res.status(404).json({ error: 'Team not found' });
    }

    team.industryPartnerId = industryPartnerId || 'ind-partner-1';
    team.industryPartnerName = industryPartnerName || 'TechCorp Innovations';
    team.committedResources = committedResources || 'Cloud Credits ($5000) + Hardware Lab Access';
    team.mentorName = mentorName || 'Industry Mentor';

    saveDB();
    res.json({ message: 'Industry partner successfully attached to research team', team });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

const { authorizeEvidenceAccess, extractUserFromRequest } = require('../middleware/authGuard');

function logAuditEvent(db, user, action, result, details = {}) {
  if (!db.researchAuditLogs) db.researchAuditLogs = [];
  db.researchAuditLogs.push({
    id: generateId(),
    user: user.name || user.email || 'User',
    role: user.role || 'public',
    universityName: user.universityName || details.universityName || null,
    orgName: user.orgName || details.orgName || null,
    researchId: details.researchId || null,
    fileId: details.fileId || null,
    action, // 'FILE_UPLOADED' | 'FILE_VIEWED' | 'FILE_DOWNLOADED' | 'RESEARCH_SHARED' | 'FILE_ACCESS_DENIED' | 'FILE_DELETED' | 'RESEARCH_ACCESS_REVOKED'
    result, // 'ALLOW' | 'DENY'
    timestamp: new Date().toISOString()
  });
}

/**
 * Get Research Progress Evidence Items (Secured by Role & Sharing State)
 */
router.get('/evidence', authorizeEvidenceAccess('read'), (req, res) => {
  try {
    const db = getDB();
    if (!db.researchEvidence) db.researchEvidence = [];
    const user = req.user || extractUserFromRequest(req);

    // Populate & normalize research evidence schema properties for existing store records
    if (db.researchEvidence.length === 0) {
      db.researchEvidence = [
        {
          id: 'evid-101',
          teamId: 'team-1',
          universityName: 'IIT Bombay',
          title: 'Mula-Mutha River AI Sensor Telemetry & Field Test Report',
          evidenceType: 'lab_report',
          description: '24-hour continuous stream telemetry metrics and field calibration log from 10 sensor microcontrollers deployed along river channel.',
          fileUrlOrLink: 'https://github.com/iitb-civic/water-sensor-pilot/docs/telemetry-report.pdf',
          metricsSummary: '94.2% AI Accuracy • 120ms Latency • 45,000 Datapoints',
          submittedBy: 'Priya Patel (Student Lead)',
          verifiedByFaculty: true,
          facultyNotes: 'Verified and validated by Prof. A. K. Sharma (IIT Bombay).',
          status: 'verified',
          sharingState: 'SHARED_WITH_INDUSTRY',
          sharedWithIndustryPartners: ['TechCorp Innovations'],
          progressStage: 'PILOT',
          progressPercentage: 65,
          createdAt: new Date(Date.now() - 3 * 86400000).toISOString()
        },
        {
          id: 'evid-102',
          teamId: 'team-1',
          universityName: 'IIT Bombay',
          title: 'Flood Level Prediction Neural Network Model Whitepaper (Draft)',
          evidenceType: 'paper_draft',
          description: 'Peer-reviewed architecture specification detailing LSTM + Spatial Convolutional networks for early urban flash-flood warning.',
          fileUrlOrLink: 'https://arxiv.org/abs/2409.12345/flood-prediction-paper.pdf',
          metricsSummary: '0.89 F1-Score • 3.2 hr Early Warning Lead Time',
          submittedBy: 'Rohan Verma (Embedded Systems Dev)',
          verifiedByFaculty: true,
          facultyNotes: 'Accepted for presentation at IEEE Civic Tech Symposium 2026.',
          status: 'verified',
          sharingState: 'PRIVATE',
          sharedWithIndustryPartners: [],
          progressStage: 'PROTOTYPE',
          progressPercentage: 45,
          createdAt: new Date(Date.now() - 1 * 86400000).toISOString()
        },
        {
          id: 'evid-103',
          teamId: 'team-1',
          universityName: 'IIT Bombay',
          title: 'Open Civic Hydrology Benchmark Dataset (v1.2)',
          evidenceType: 'dataset',
          description: 'Cleaned and labeled multi-spectral satellite + ground sensor dataset covering 15 flood-prone urban zones in Maharashtra.',
          fileUrlOrLink: 'https://huggingface.co/datasets/civic-tech/maharashtra-floods-2026',
          metricsSummary: '1.2 GB • 150,000 Records • CC-BY-4.0 License',
          submittedBy: 'Priya Patel (Student Lead)',
          verifiedByFaculty: false,
          facultyNotes: 'Pending final data governance review by faculty advisor.',
          status: 'under_review',
          sharingState: 'PRIVATE',
          sharedWithIndustryPartners: [],
          progressStage: 'RESEARCH',
          progressPercentage: 25,
          createdAt: new Date().toISOString()
        }
      ];
      saveDB();
    } else {
      // Normalize missing properties on existing items
      let modified = false;
      db.researchEvidence.forEach(e => {
        if (!e.universityName) { e.universityName = 'IIT Bombay'; modified = true; }
        if (!e.progressStage) { e.progressStage = 'PROTOTYPE'; modified = true; }
        if (e.progressPercentage === undefined) { e.progressPercentage = 35; modified = true; }
        if (!e.sharingState) { 
          if (e.id === 'evid-101') {
            e.sharingState = 'SHARED_WITH_INDUSTRY';
            e.sharedWithIndustryPartners = ['TechCorp Innovations'];
          } else {
            e.sharingState = 'PRIVATE';
            e.sharedWithIndustryPartners = [];
          }
          modified = true;
        }
      });
      if (modified) saveDB();
    }

    let filtered = [];

    if (user.role === 'university') {
      // University callers see ONLY their own university's research
      const targetUniv = user.universityName || 'IIT Bombay';
      filtered = db.researchEvidence.filter(e => (e.universityName || 'IIT Bombay') === targetUniv);
    } else if (user.role === 'industry') {
      // Industry callers see ONLY items with sharingState === 'SHARED_WITH_INDUSTRY' matching their org
      const targetOrg = user.orgName || 'TechCorp Innovations';
      filtered = db.researchEvidence.filter(e => 
        e.sharingState === 'SHARED_WITH_INDUSTRY' && 
        Array.isArray(e.sharedWithIndustryPartners) && 
        e.sharedWithIndustryPartners.includes(targetOrg)
      );
    } else if (user.role === 'admin') {
      // System admin sees all records for platform oversight
      filtered = db.researchEvidence;
    } else {
      // Citizen / Public callers get 0 records
      filtered = [];
    }

    // Attach file metadata to each evidence record
    if (!db.researchEvidenceFiles) db.researchEvidenceFiles = [];
    const enriched = filtered.map(item => ({
      ...item,
      files: db.researchEvidenceFiles.filter(f => f.researchId === item.id)
    }));

    res.json({ evidence: enriched });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Submit New Research Evidence Item (University Only)
 */
router.post('/evidence', authorizeEvidenceAccess('write'), (req, res) => {
  try {
    const { title, evidenceType, description, fileUrlOrLink, metricsSummary, submittedBy, progressStage, progressPercentage } = req.body;
    const user = req.user || extractUserFromRequest(req);

    if (!title || !evidenceType || !description) {
      return res.status(400).json({ error: 'Title, evidence type, and description are required.' });
    }

    const db = getDB();
    if (!db.researchEvidence) db.researchEvidence = [];

    const validStages = ['IDEA', 'RESEARCH', 'PROTOTYPE', 'TESTING', 'PILOT', 'COMPLETED'];
    const stage = validStages.includes(progressStage) ? progressStage : 'PROTOTYPE';
    const percentage = typeof progressPercentage === 'number' && progressPercentage >= 0 && progressPercentage <= 100 
      ? progressPercentage 
      : 35;

    const newEvidence = {
      id: generateId(),
      teamId: 'team-1',
      universityName: user.universityName || 'IIT Bombay',
      title,
      evidenceType: evidenceType || 'lab_report',
      description,
      fileUrlOrLink: fileUrlOrLink || 'https://github.com/iitb-civic/research-repository',
      metricsSummary: metricsSummary || 'Validated by Lab Benchmarks',
      submittedBy: submittedBy || user.name || 'University Research Lead',
      verifiedByFaculty: false,
      facultyNotes: 'Awaiting faculty advisor endorsement.',
      status: 'under_review',
      sharingState: 'PRIVATE',
      sharedWithIndustryPartners: [],
      progressStage: stage,
      progressPercentage: percentage,
      createdAt: new Date().toISOString()
    };

    db.researchEvidence.unshift(newEvidence);
    saveDB();

    res.json({ message: 'Research progress evidence submitted successfully', evidence: newEvidence });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Update Research Progress Stage & Percentage (University Owner Only)
 */
router.patch('/evidence/:id/progress', authorizeEvidenceAccess('write'), (req, res) => {
  try {
    const { id } = req.params;
    const { progressStage, progressPercentage } = req.body;
    const user = req.user || extractUserFromRequest(req);

    const db = getDB();
    if (!db.researchEvidence) db.researchEvidence = [];

    const item = db.researchEvidence.find(e => e.id === id);
    if (!item) return res.status(404).json({ error: 'Evidence record not found' });

    if (user.role === 'university' && (item.universityName || 'IIT Bombay') !== (user.universityName || 'IIT Bombay')) {
      return res.status(403).json({ error: 'Forbidden: Cannot update progress for another university research.' });
    }

    const validStages = ['IDEA', 'RESEARCH', 'PROTOTYPE', 'TESTING', 'PILOT', 'COMPLETED'];
    if (progressStage && validStages.includes(progressStage)) {
      item.progressStage = progressStage;
    }
    if (typeof progressPercentage === 'number' && progressPercentage >= 0 && progressPercentage <= 100) {
      item.progressPercentage = progressPercentage;
    }

    saveDB();
    res.json({ message: 'Research progress updated successfully', evidence: item });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Toggle Industry Sharing State & Select Partners (University Owner Only)
 */
router.post('/evidence/:id/share', authorizeEvidenceAccess('write'), (req, res) => {
  try {
    const { id } = req.params;
    const { sharingState, partnerName } = req.body; // sharingState: 'PRIVATE' | 'SHARED_WITH_INDUSTRY'
    const user = req.user || extractUserFromRequest(req);

    const db = getDB();
    if (!db.researchEvidence) db.researchEvidence = [];

    const item = db.researchEvidence.find(e => e.id === id);
    if (!item) {
      return res.status(404).json({ error: 'Evidence record not found' });
    }

    // Verify ownership
    if (user.role === 'university' && item.universityName && item.universityName !== (user.universityName || 'IIT Bombay')) {
      return res.status(403).json({ error: 'Forbidden: You can only manage sharing for your own university research.' });
    }

    const targetPartner = partnerName || 'TechCorp Innovations';
    if (!Array.isArray(item.sharedWithIndustryPartners)) {
      item.sharedWithIndustryPartners = [];
    }

    if (sharingState === 'SHARED_WITH_INDUSTRY') {
      item.sharingState = 'SHARED_WITH_INDUSTRY';
      if (!item.sharedWithIndustryPartners.includes(targetPartner)) {
        item.sharedWithIndustryPartners.push(targetPartner);
      }
    } else {
      item.sharingState = 'PRIVATE';
      item.sharedWithIndustryPartners = [];
    }

    saveDB();
    res.json({ message: 'Research sharing configuration updated', evidence: item });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Faculty Advisor Verification Toggle
 */
router.patch('/evidence/:id/verify', authorizeEvidenceAccess('write'), (req, res) => {
  try {
    const { id } = req.params;
    const { facultyNotes } = req.body;

    const db = getDB();
    if (!db.researchEvidence) db.researchEvidence = [];

    const item = db.researchEvidence.find(e => e.id === id);
    if (!item) {
      return res.status(404).json({ error: 'Evidence record not found' });
    }

    item.verifiedByFaculty = !item.verifiedByFaculty;
    item.status = item.verifiedByFaculty ? 'verified' : 'under_review';
    item.facultyNotes = item.verifiedByFaculty 
      ? (facultyNotes || 'Verified and endorsed by Faculty Research Advisor.')
      : 'Awaiting faculty advisor endorsement.';

    saveDB();
    res.json({ message: 'Evidence verification status updated', evidence: item });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * GET Active & Revoked Shares for a Research Evidence Item
 */
router.get('/evidence/:id/shares', authorizeEvidenceAccess('read'), (req, res) => {
  try {
    const { id } = req.params;
    const db = getDB();
    if (!db.researchShares) db.researchShares = [];

    const shares = db.researchShares.filter(s => s.researchId === id);
    res.json({ shares });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Share Research Evidence with Explicit Industry Partner
 */
router.post('/evidence/:id/share-partner', authorizeEvidenceAccess('write'), (req, res) => {
  try {
    const { id } = req.params;
    const { partnerId, partnerName, sharedFields, expiresAt } = req.body;
    const user = req.user || extractUserFromRequest(req);

    const db = getDB();
    if (!db.researchEvidence) db.researchEvidence = [];
    if (!db.researchShares) db.researchShares = [];
    if (!db.researchAuditLogs) db.researchAuditLogs = [];

    const item = db.researchEvidence.find(e => e.id === id);
    if (!item) return res.status(404).json({ error: 'Evidence record not found' });

    // Verify University Ownership
    if (user.role === 'university' && item.universityName && item.universityName !== (user.universityName || 'IIT Bombay')) {
      return res.status(403).json({ error: 'Forbidden: You can only manage sharing for your own university research.' });
    }

    const targetPartnerName = partnerName || 'TechCorp Innovations';
    const targetPartnerId = partnerId || targetPartnerName;

    const defaultSharedFields = {
      share_title: true,
      share_description: true,
      share_progress_stage: true,
      share_metrics: true,
      share_tech_findings: true,
      share_demo_info: false,
      share_paper: false,
      share_dataset: false,
      share_files: false
    };

    const fieldsToShare = sharedFields || defaultSharedFields;
    const expiryDate = expiresAt || null;

    // Update or insert share record
    let share = db.researchShares.find(s => s.researchId === id && (s.industryPartnerId === targetPartnerId || s.industryPartnerName === targetPartnerName));
    if (share) {
      share.status = 'ACTIVE';
      share.sharedAt = new Date().toISOString();
      share.sharedBy = user.name || 'University Research Lead';
      share.sharedFields = fieldsToShare;
      share.expiresAt = expiryDate;
    } else {
      share = {
        id: generateId(),
        researchId: id,
        universityName: item.universityName || 'IIT Bombay',
        industryPartnerId: targetPartnerId,
        industryPartnerName: targetPartnerName,
        sharedBy: user.name || 'University Research Lead',
        sharedAt: new Date().toISOString(),
        status: 'ACTIVE',
        sharedFields: fieldsToShare,
        expiresAt: expiryDate
      };
      db.researchShares.push(share);
    }

    // Ensure item.sharingState is SHARED_WITH_INDUSTRY and partner is in array
    item.sharingState = 'SHARED_WITH_INDUSTRY';
    if (!Array.isArray(item.sharedWithIndustryPartners)) item.sharedWithIndustryPartners = [];
    if (!item.sharedWithIndustryPartners.includes(targetPartnerName)) {
      item.sharedWithIndustryPartners.push(targetPartnerName);
    }

    // Record Audit Log
    db.researchAuditLogs.push({
      id: generateId(),
      researchId: id,
      universityName: item.universityName || 'IIT Bombay',
      industryPartnerId: targetPartnerName,
      performedBy: user.name || 'University Research Lead',
      timestamp: new Date().toISOString(),
      action: 'RESEARCH_SHARED',
      fieldsShared: fieldsToShare
    });

    saveDB();
    res.json({ message: `Research successfully shared with ${targetPartnerName}`, share, evidence: item });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Revoke Industry Partner Access to Research Evidence
 */
router.post('/evidence/:id/revoke-share', authorizeEvidenceAccess('write'), (req, res) => {
  try {
    const { id } = req.params;
    const { partnerName, partnerId } = req.body;
    const user = req.user || extractUserFromRequest(req);

    const db = getDB();
    if (!db.researchEvidence) db.researchEvidence = [];
    if (!db.researchShares) db.researchShares = [];
    if (!db.researchAuditLogs) db.researchAuditLogs = [];

    const item = db.researchEvidence.find(e => e.id === id);
    if (!item) return res.status(404).json({ error: 'Evidence record not found' });

    // Verify University Ownership
    if (user.role === 'university' && item.universityName && item.universityName !== (user.universityName || 'IIT Bombay')) {
      return res.status(403).json({ error: 'Forbidden: You can only revoke sharing for your own university research.' });
    }

    const targetPartnerName = partnerName || 'TechCorp Innovations';
    const targetPartnerId = partnerId || targetPartnerName;

    // Set share record status to REVOKED
    const share = db.researchShares.find(s => s.researchId === id && (s.industryPartnerId === targetPartnerId || s.industryPartnerName === targetPartnerName));
    if (share) {
      share.status = 'REVOKED';
    }

    // Remove partner from evidence's active shared array
    if (Array.isArray(item.sharedWithIndustryPartners)) {
      item.sharedWithIndustryPartners = item.sharedWithIndustryPartners.filter(p => p !== targetPartnerName && p !== targetPartnerId);
    }

    // Check if any active shares remain
    const activeShares = db.researchShares.filter(s => s.researchId === id && s.status === 'ACTIVE');
    if (activeShares.length === 0 && (!item.sharedWithIndustryPartners || item.sharedWithIndustryPartners.length === 0)) {
      item.sharingState = 'PRIVATE';
    }

    // Record Audit Log
    db.researchAuditLogs.push({
      id: generateId(),
      researchId: id,
      universityName: item.universityName || 'IIT Bombay',
      industryPartnerId: targetPartnerName,
      performedBy: user.name || 'University Research Lead',
      timestamp: new Date().toISOString(),
      action: 'RESEARCH_ACCESS_REVOKED'
    });

    saveDB();
    res.json({ message: `Access revoked for ${targetPartnerName}`, evidence: item });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Get Research Shared With Currently Authenticated Industry Partner (Industry Portal)
 */
router.get('/evidence-shared-with-us', (req, res) => {
  try {
    const user = extractUserFromRequest(req);
    if (user.role !== 'industry' && user.role !== 'admin') {
      return res.status(403).json({ error: 'Forbidden: Only authenticated industry partners can view shared research.' });
    }

    const targetOrg = user.orgName || 'TechCorp Innovations';
    const db = getDB();
    if (!db.researchEvidence) db.researchEvidence = [];
    if (!db.researchShares) db.researchShares = [];

    // Filter active, non-expired shares for targetOrg
    const activeShareRecords = db.researchShares.filter(s => 
      (s.industryPartnerId === targetOrg || s.industryPartnerName === targetOrg) && 
      s.status === 'ACTIVE' && 
      (!s.expiresAt || new Date(s.expiresAt) > new Date())
    );

    const activeShareMap = new Map();
    activeShareRecords.forEach(s => activeShareMap.set(s.researchId, s));

    const sharedEvidence = db.researchEvidence.filter(e => activeShareMap.has(e.id));

    if (!db.researchEvidenceFiles) db.researchEvidenceFiles = [];

    // SERVER-SIDE FIELD-LEVEL SANITIZATION
    const enrichedShared = sharedEvidence.map(item => {
      const share = activeShareMap.get(item.id);
      const fields = (share && share.sharedFields) ? share.sharedFields : {
        share_title: true,
        share_description: true,
        share_progress_stage: true,
        share_metrics: true,
        share_tech_findings: true,
        share_demo_info: false,
        share_paper: false,
        share_dataset: false,
        share_files: false
      };

      return {
        id: item.id,
        teamId: item.teamId,
        universityName: item.universityName,
        sharingState: item.sharingState,
        submittedBy: item.submittedBy,
        createdAt: item.createdAt,
        isIndustryReadOnly: true,
        sharedByUniversityName: item.universityName,
        sharedFields: fields,
        expiresAt: share ? share.expiresAt : null,

        // Sanitized Fields
        title: fields.share_title ? item.title : 'Confidential Research Project',
        evidenceType: item.evidenceType,
        description: fields.share_description ? item.description : '[Private Description — Not Shared by University]',
        progressStage: fields.share_progress_stage ? (item.progressStage || 'PROTOTYPE') : null,
        progressPercentage: fields.share_progress_stage ? (item.progressPercentage !== undefined ? item.progressPercentage : 35) : null,
        metricsSummary: fields.share_metrics ? item.metricsSummary : '[Private Metrics — Not Shared by University]',
        techFindings: fields.share_tech_findings ? (item.description || item.techFindings) : '[Private Technical Findings — Not Shared]',
        
        // Link sanitization according to type & permissions
        fileUrlOrLink: (
          (item.evidenceType === 'demo_video' && fields.share_demo_info) ||
          (item.evidenceType === 'paper_draft' && fields.share_paper) ||
          (item.evidenceType === 'dataset' && fields.share_dataset)
        ) ? item.fileUrlOrLink : null,

        // File attachments sanitization
        files: fields.share_files ? db.researchEvidenceFiles.filter(f => f.researchId === item.id) : []
      };
    });

    res.json({ evidence: enrichedShared, orgName: targetOrg });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Get Research Sharing Audit Trail Logs
 */
router.get('/audit-logs', (req, res) => {
  try {
    const user = extractUserFromRequest(req);
    const db = getDB();
    if (!db.researchAuditLogs) db.researchAuditLogs = [];

    let logs = db.researchAuditLogs;
    if (user.role === 'university') {
      logs = logs.filter(l => l.universityName === (user.universityName || 'IIT Bombay'));
    }

    res.json({ logs });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Get Verified Industry Partners List
 */
router.get('/industry-partners', (req, res) => {
  try {
    const db = getDB();
    const dbIndustryUsers = (db.users || [])
      .filter(u => u.role === 'industry')
      .map(u => u.orgName || u.name)
      .filter(Boolean);

    const defaultPartners = [
      'TechCorp Innovations',
      'Tata Research & Innovation',
      'Reliance Industries',
      'Infosys Innovation Lab'
    ];

    const partnersSet = new Set([...dbIndustryUsers, ...defaultPartners]);
    const partnersList = Array.from(partnersSet).map(name => ({
      id: name,
      name,
      verified: true
    }));

    res.json({ partners: partnersList });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Get Single Research Evidence Item by ID (Secured by Role & Ownership/Sharing Rules)
 */
router.get('/evidence/:id', authorizeEvidenceAccess('read'), (req, res) => {
  try {
    const { id } = req.params;
    const user = req.user || extractUserFromRequest(req);
    const db = getDB();
    if (!db.researchEvidence) db.researchEvidence = [];
    if (!db.researchShares) db.researchShares = [];

    const item = db.researchEvidence.find(e => e.id === id);
    if (!item) {
      return res.status(404).json({ error: 'Evidence record not found' });
    }

    // 1. Citizens & Public callers get 403 Forbidden
    if (['citizen', 'public'].includes(user.role)) {
      logAuditEvent(db, user, 'FILE_ACCESS_DENIED', 'DENY', { researchId: id, universityName: item.universityName });
      return res.status(403).json({ error: 'Forbidden: Research evidence is confidential and restricted.' });
    }

    // 2. University callers can ONLY view their own university's evidence
    if (user.role === 'university') {
      const callerUniv = user.universityName || 'IIT Bombay';
      if ((item.universityName || 'IIT Bombay') !== callerUniv) {
        logAuditEvent(db, user, 'FILE_ACCESS_DENIED', 'DENY', { researchId: id, universityName: item.universityName });
        return res.status(403).json({ error: 'Forbidden: Cannot access another university private research.' });
      }
    }

    // 3. Industry callers can ONLY view items if an ACTIVE share record exists for their org
    if (user.role === 'industry') {
      const callerOrg = user.orgName || 'TechCorp Innovations';
      const hasActiveShare = db.researchShares.some(s => 
        s.researchId === id && 
        (s.industryPartnerId === callerOrg || s.industryPartnerName === callerOrg) && 
        s.status === 'ACTIVE'
      );
      const isSharedInArray = item.sharingState === 'SHARED_WITH_INDUSTRY' && 
                              Array.isArray(item.sharedWithIndustryPartners) && 
                              item.sharedWithIndustryPartners.includes(callerOrg);

      if (!hasActiveShare && !isSharedInArray) {
        logAuditEvent(db, user, 'FILE_ACCESS_DENIED', 'DENY', { researchId: id, universityName: item.universityName });
        return res.status(403).json({ error: 'Forbidden: Research record is private or shared with a different industry partner.' });
      }
    }

    logAuditEvent(db, user, 'FILE_VIEWED', 'ALLOW', { researchId: id, universityName: item.universityName });
    res.json({ evidence: item });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Delete Research Evidence Item (Owning University Only)
 */
router.delete('/evidence/:id', authorizeEvidenceAccess('write'), (req, res) => {
  try {
    const { id } = req.params;
    const user = req.user || extractUserFromRequest(req);
    const db = getDB();
    if (!db.researchEvidence) db.researchEvidence = [];

    const index = db.researchEvidence.findIndex(e => e.id === id);
    if (index === -1) {
      return res.status(404).json({ error: 'Evidence record not found' });
    }

    const item = db.researchEvidence[index];

    // Industry callers CANNOT delete
    if (user.role === 'industry') {
      return res.status(403).json({ error: 'Forbidden: Industry partners have Read-Only access.' });
    }

    // University callers can ONLY delete their own university's record
    if (user.role === 'university' && (item.universityName || 'IIT Bombay') !== (user.universityName || 'IIT Bombay')) {
      return res.status(403).json({ error: 'Forbidden: Cannot delete another university research record.' });
    }

    db.researchEvidence.splice(index, 1);
    saveDB();

    res.json({ message: 'Research evidence record deleted successfully', deletedId: id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Download Confidential Storage File (Secured Path Access Check)
 */
router.get('/evidence/:id/download', authorizeEvidenceAccess('read'), (req, res) => {
  try {
    const { id } = req.params;
    const user = req.user || extractUserFromRequest(req);
    const db = getDB();
    if (!db.researchEvidence) db.researchEvidence = [];
    if (!db.researchShares) db.researchShares = [];

    const item = db.researchEvidence.find(e => e.id === id);
    if (!item) {
      return res.status(404).json({ error: 'Evidence record or file not found' });
    }

    // Security Check: University ownership or Industry explicit share check
    if (user.role === 'university' && (item.universityName || 'IIT Bombay') !== (user.universityName || 'IIT Bombay')) {
      return res.status(403).json({ error: 'Forbidden: Unauthorized file access.' });
    }

    if (user.role === 'industry') {
      const callerOrg = user.orgName || 'TechCorp Innovations';
      const hasActiveShare = db.researchShares.some(s => 
        s.researchId === id && 
        (s.industryPartnerId === callerOrg || s.industryPartnerName === callerOrg) && 
        s.status === 'ACTIVE'
      );
      const isSharedInArray = item.sharingState === 'SHARED_WITH_INDUSTRY' && 
                              Array.isArray(item.sharedWithIndustryPartners) && 
                              item.sharedWithIndustryPartners.includes(callerOrg);

      if (!hasActiveShare && !isSharedInArray) {
        return res.status(403).json({ error: 'Forbidden: Unauthorized file access.' });
      }
    }

    if (['citizen', 'public'].includes(user.role)) {
      return res.status(403).json({ error: 'Forbidden: Unauthorized file access.' });
    }

    res.json({ 
      downloadUrl: item.fileUrlOrLink, 
      storagePath: `universities/${item.universityName || 'IIT-Bombay'}/research/${item.id}/report.pdf`,
      accessStatus: 'AUTHORIZED' 
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Upload Files for a Research Evidence Item (University Owner Only)
 */
router.post('/evidence/:id/files', authorizeEvidenceAccess('write'), (req, res) => {
  try {
    const { id } = req.params;
    const { files } = req.body; // Array of { fileName, fileType, fileSize, mimeType, fileData }
    const user = req.user || extractUserFromRequest(req);

    if (user.role === 'industry') {
      return res.status(403).json({ error: 'Forbidden: Industry partners cannot upload research files.' });
    }

    const db = getDB();
    if (!db.researchEvidence) db.researchEvidence = [];
    if (!db.researchEvidenceFiles) db.researchEvidenceFiles = [];

    const item = db.researchEvidence.find(e => e.id === id);
    if (!item) {
      return res.status(404).json({ error: 'Evidence record not found' });
    }

    if (user.role === 'university' && (item.universityName || 'IIT Bombay') !== (user.universityName || 'IIT Bombay')) {
      return res.status(403).json({ error: 'Forbidden: Cannot upload files to another university research.' });
    }

    if (!Array.isArray(files) || files.length === 0) {
      return res.status(400).json({ error: 'No files provided for upload.' });
    }

    const allowedExtensions = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'xls', 'xlsx', 'csv', 'jpg', 'jpeg', 'png', 'webp', 'mp4', 'mov', 'webm'];
    const createdFiles = [];

    for (const f of files) {
      const ext = (f.fileName || '').split('.').pop().toLowerCase();
      if (!allowedExtensions.includes(ext)) {
        return res.status(400).json({ error: `Unsupported file type: .${ext}. Please select a valid research evidence file.` });
      }

      const fileId = generateId();
      const safeName = (f.fileName || 'file').replace(/[^a-zA-Z0-9._-]/g, '_');
      const univSlug = (item.universityName || 'IIT Bombay').toLowerCase().replace(/[^a-z0-9]/g, '-');
      const storagePath = `research-evidence/university/${univSlug}/research/${id}/${fileId}-${safeName}`;

      const newFile = {
        id: fileId,
        researchId: id,
        universityId: item.universityName || user.universityName || 'IIT Bombay',
        uploadedBy: user.name || 'University Research Lead',
        fileName: f.fileName,
        fileType: f.fileType || 'document',
        fileSize: f.fileSize || 1024,
        mimeType: f.mimeType || 'application/octet-stream',
        storagePath,
        fileData: f.fileData || null,
        createdAt: new Date().toISOString()
      };

      db.researchEvidenceFiles.push(newFile);
      createdFiles.push(newFile);
    }

    saveDB();
    res.json({ message: 'Files uploaded successfully to private storage vault', files: createdFiles });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Get List of Files attached to Research Evidence Item
 */
router.get('/evidence/:id/files', authorizeEvidenceAccess('read'), (req, res) => {
  try {
    const { id } = req.params;
    const user = req.user || extractUserFromRequest(req);
    const db = getDB();
    if (!db.researchEvidence) db.researchEvidence = [];
    if (!db.researchEvidenceFiles) db.researchEvidenceFiles = [];
    if (!db.researchShares) db.researchShares = [];

    const item = db.researchEvidence.find(e => e.id === id);
    if (!item) return res.status(404).json({ error: 'Evidence record not found' });

    // Authorization check
    if (['citizen', 'public'].includes(user.role)) {
      return res.status(403).json({ error: 'Forbidden: Unauthorized file access.' });
    }

    if (user.role === 'university' && (item.universityName || 'IIT Bombay') !== (user.universityName || 'IIT Bombay')) {
      return res.status(403).json({ error: 'Forbidden: Unauthorized file access.' });
    }

    if (user.role === 'industry') {
      const callerOrg = user.orgName || 'TechCorp Innovations';
      const hasActiveShare = db.researchShares.some(s => 
        s.researchId === id && 
        (s.industryPartnerId === callerOrg || s.industryPartnerName === callerOrg) && 
        s.status === 'ACTIVE'
      );
      if (!hasActiveShare) {
        return res.status(403).json({ error: 'Forbidden: Unauthorized file access.' });
      }
    }

    const files = db.researchEvidenceFiles.filter(f => f.researchId === id);
    res.json({ files });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Generate Short-Lived Signed URL for Private Research File
 */
router.get('/evidence/files/:fileId/signed-url', (req, res) => {
  try {
    const { fileId } = req.params;
    const user = extractUserFromRequest(req);
    const db = getDB();
    if (!db.researchEvidenceFiles) db.researchEvidenceFiles = [];
    if (!db.researchEvidence) db.researchEvidence = [];
    if (!db.researchShares) db.researchShares = [];

    const file = db.researchEvidenceFiles.find(f => f.id === fileId);
    if (!file) return res.status(404).json({ error: 'File record not found' });

    const item = db.researchEvidence.find(e => e.id === file.researchId);
    if (!item) return res.status(404).json({ error: 'Associated research record not found' });

    // Enforce Authorization Rules
    if (['citizen', 'public'].includes(user.role)) {
      logAuditEvent(db, user, 'FILE_ACCESS_DENIED', 'DENY', { fileId, researchId: file.researchId });
      return res.status(403).json({ error: 'Forbidden: Confidential file access restricted.' });
    }

    if (user.role === 'university' && (item.universityName || 'IIT Bombay') !== (user.universityName || 'IIT Bombay')) {
      logAuditEvent(db, user, 'FILE_ACCESS_DENIED', 'DENY', { fileId, researchId: file.researchId });
      return res.status(403).json({ error: 'Forbidden: Cannot access another university file.' });
    }

    if (user.role === 'industry') {
      const callerOrg = user.orgName || 'TechCorp Innovations';
      const activeShare = db.researchShares.find(s => 
        s.researchId === file.researchId && 
        (s.industryPartnerId === callerOrg || s.industryPartnerName === callerOrg) && 
        s.status === 'ACTIVE' &&
        (!s.expiresAt || new Date(s.expiresAt) > new Date())
      );
      if (!activeShare) {
        logAuditEvent(db, user, 'FILE_ACCESS_DENIED', 'DENY', { fileId, researchId: file.researchId });
        return res.status(403).json({ error: 'Forbidden: Industry access revoked or unshared.' });
      }
      if (activeShare.sharedFields && activeShare.sharedFields.share_files === false) {
        logAuditEvent(db, user, 'FILE_ACCESS_DENIED', 'DENY', { fileId, researchId: file.researchId });
        return res.status(403).json({ error: 'Forbidden: Attached evidence files were not explicitly shared by the university.' });
      }
    }

    // Generate short-lived signed token (valid for 15 minutes = 900 seconds)
    const expiresAt = Date.now() + 15 * 60 * 1000;
    const signedToken = Buffer.from(`${fileId}:${expiresAt}:${user.role}`).toString('base64');
    const signedUrl = `/api/teams/evidence/files/${fileId}/download?token=${signedToken}`;

    logAuditEvent(db, user, 'FILE_VIEWED', 'ALLOW', { fileId, researchId: file.researchId });

    res.json({ 
      signedUrl, 
      expiresAt: new Date(expiresAt).toISOString(),
      fileName: file.fileName,
      storagePath: file.storagePath 
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Secure File Download Stream Endpoint
 */
router.get('/evidence/files/:fileId/download', (req, res) => {
  try {
    const { fileId } = req.params;
    const user = extractUserFromRequest(req);
    const db = getDB();
    if (!db.researchEvidenceFiles) db.researchEvidenceFiles = [];
    if (!db.researchEvidence) db.researchEvidence = [];
    if (!db.researchShares) db.researchShares = [];

    const file = db.researchEvidenceFiles.find(f => f.id === fileId);
    if (!file) return res.status(404).json({ error: 'File record not found' });

    const item = db.researchEvidence.find(e => e.id === file.researchId);
    if (!item) return res.status(404).json({ error: 'Associated research record not found' });

    // Authorization Verification
    if (['citizen', 'public'].includes(user.role)) {
      logAuditEvent(db, user, 'FILE_ACCESS_DENIED', 'DENY', { fileId, researchId: file.researchId });
      return res.status(403).json({ error: 'Forbidden: Access denied.' });
    }

    if (user.role === 'university' && (item.universityName || 'IIT Bombay') !== (user.universityName || 'IIT Bombay')) {
      logAuditEvent(db, user, 'FILE_ACCESS_DENIED', 'DENY', { fileId, researchId: file.researchId });
      return res.status(403).json({ error: 'Forbidden: Access denied.' });
    }

    if (user.role === 'industry') {
      const callerOrg = user.orgName || 'TechCorp Innovations';
      const activeShare = db.researchShares.find(s => 
        s.researchId === file.researchId && 
        (s.industryPartnerId === callerOrg || s.industryPartnerName === callerOrg) && 
        s.status === 'ACTIVE' &&
        (!s.expiresAt || new Date(s.expiresAt) > new Date())
      );
      if (!activeShare) {
        logAuditEvent(db, user, 'FILE_ACCESS_DENIED', 'DENY', { fileId, researchId: file.researchId });
        return res.status(403).json({ error: 'Forbidden: Industry access revoked or unshared.' });
      }
      if (activeShare.sharedFields && activeShare.sharedFields.share_files === false) {
        logAuditEvent(db, user, 'FILE_ACCESS_DENIED', 'DENY', { fileId, researchId: file.researchId });
        return res.status(403).json({ error: 'Forbidden: Attached evidence files were not explicitly shared by the university.' });
      }
    }

    logAuditEvent(db, user, 'FILE_DOWNLOADED', 'ALLOW', { fileId, researchId: file.researchId });

    // Serve file content or data stream
    res.setHeader('Content-Type', file.mimeType || 'application/octet-stream');
    res.setHeader('Content-Disposition', `inline; filename="${file.fileName}"`);

    if (file.fileData && file.fileData.startsWith('data:')) {
      const base64Data = file.fileData.split(',')[1];
      const buffer = Buffer.from(base64Data, 'base64');
      return res.send(buffer);
    }

    res.json({
      fileId: file.id,
      fileName: file.fileName,
      storagePath: file.storagePath,
      message: 'Private Supabase Storage file stream authorized.'
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Delete File from Evidence Record (Owning University Only)
 */
router.delete('/evidence/files/:fileId', authorizeEvidenceAccess('write'), (req, res) => {
  try {
    const { fileId } = req.params;
    const user = req.user || extractUserFromRequest(req);
    const db = getDB();
    if (!db.researchEvidenceFiles) db.researchEvidenceFiles = [];
    if (!db.researchEvidence) db.researchEvidence = [];

    if (user.role === 'industry') {
      return res.status(403).json({ error: 'Forbidden: Industry partners cannot delete research files.' });
    }

    const index = db.researchEvidenceFiles.findIndex(f => f.id === fileId);
    if (index === -1) return res.status(404).json({ error: 'File record not found' });

    const file = db.researchEvidenceFiles[index];
    const item = db.researchEvidence.find(e => e.id === file.researchId);

    if (user.role === 'university' && item && (item.universityName || 'IIT Bombay') !== (user.universityName || 'IIT Bombay')) {
      return res.status(403).json({ error: 'Forbidden: Cannot delete file belonging to another university.' });
    }

    db.researchEvidenceFiles.splice(index, 1);
    saveDB();

    res.json({ message: 'File deleted successfully', deletedFileId: fileId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
