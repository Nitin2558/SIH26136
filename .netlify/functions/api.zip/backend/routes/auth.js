const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { getDB, saveDB, generateId } = require('../db/store');
const { sendOTP, verifyOTP, cleanPhoneNumber } = require('../services/twofactor');

const JWT_SECRET = process.env.JWT_SECRET || 'sih-civic-secret-key-2026';

/**
 * Send Real Mobile OTP (SMS or Voice Call) via 2Factor
 */
router.post('/otp/send', async (req, res) => {
  try {
    const { phone, method = 'sms' } = req.body;
    if (!phone) {
      return res.status(400).json({ error: 'Please enter a valid 10-digit mobile number.' });
    }
    const result = await sendOTP(phone, method);
    if (!result.success) {
      const status = result.cooldown ? 429 : 400;
      return res.status(status).json({ error: result.error, cooldown: result.cooldown, remainingSecs: result.remainingSecs });
    }
    res.json({
      success: true,
      sessionId: result.sessionId,
      phone: result.phone,
      method: result.method || method,
      message: result.message
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

/**
 * Verify Mobile OTP (SMS or Voice Call) and Login/Register
 */
router.post('/otp/verify', async (req, res) => {
  try {
    const { sessionId, otp, phone, role, method = 'sms' } = req.body;
    if (!sessionId || !otp || !phone) {
      return res.status(400).json({ error: 'Session ID, OTP, and phone number are required.' });
    }

    const cleanPhone = cleanPhoneNumber(phone);
    const verification = await verifyOTP(sessionId, otp, method);
    if (!verification.success) {
      return res.status(400).json({ error: verification.error || 'Invalid OTP code. Please check and try again.' });
    }

    const db = getDB();
    if (!db.users) db.users = [];

    // Find existing user by phone
    let user = db.users.find(u => u.phone === cleanPhone);
    let isNewUser = false;

    if (!user) {
      // Automatic Provisioning of citizen account
      isNewUser = true;
      user = {
        id: generateId(),
        name: `Citizen ${cleanPhone.slice(-4)}`,
        phone: cleanPhone,
        phoneVerified: true,
        email: '',
        role: role || 'citizen',
        profileCompleted: false,
        locationState: '',
        createdAt: new Date().toISOString()
      };
      db.users.push(user);
      saveDB();
    } else {
      user.phoneVerified = true;
      saveDB();
    }

    const token = jwt.sign(
      { id: user.id, role: user.role, name: user.name, phone: user.phone },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    const { passwordHash: _, ...userWithoutPass } = user;
    res.json({
      success: true,
      token,
      user: userWithoutPass,
      isNewUser,
      message: isNewUser ? 'Mobile verified! Welcome to Civic Innovation Platform.' : 'Login successful!'
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Update / Complete Profile (Instagram-style post-login completion)
 */
router.put('/profile', (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const db = getDB();
    const userIndex = db.users.findIndex(u => u.id === decoded.id);
    if (userIndex === -1) {
      return res.status(404).json({ error: 'User not found' });
    }

    const user = db.users[userIndex];
    const { name, email, locationState, orgName, universityName, departmentName, role } = req.body;

    if (name && name.trim()) user.name = name.trim();
    if (email && email.trim()) user.email = email.toLowerCase().trim();
    if (locationState) user.locationState = locationState.trim();
    if (orgName) user.orgName = orgName.trim();
    if (universityName) user.universityName = universityName.trim();
    if (departmentName) user.departmentName = departmentName.trim();
    if (role && ['citizen', 'government', 'university', 'industry'].includes(role)) {
      user.role = role;
    }

    user.profileCompleted = true;
    user.updatedAt = new Date().toISOString();

    db.users[userIndex] = user;
    saveDB();

    const { passwordHash: _, ...userWithoutPass } = user;
    res.json({
      success: true,
      user: userWithoutPass,
      message: 'Profile updated successfully!'
    });
  } catch (err) {
    res.status(401).json({ error: 'Invalid or expired session token' });
  }
});

/**
 * Register User
 */
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, role, orgName, universityName, departmentName } = req.body;

    if (!name || !email || !password || !role) {
      return res.status(400).json({ error: 'Name, email, password, and role are required.' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters long.' });
    }

    const db = getDB();
    const existing = db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (existing) {
      return res.status(400).json({ error: 'An account with this email address already exists.' });
    }

    const passwordHash = await bcrypt.hash(password, 10);

    const newUser = {
      id: generateId(),
      name: name.trim(),
      email: email.toLowerCase().trim(),
      role: role || 'citizen',
      passwordHash,
      orgName: orgName ? orgName.trim() : '',
      universityName: universityName ? universityName.trim() : '',
      departmentName: departmentName ? departmentName.trim() : '',
      createdAt: new Date().toISOString()
    };

    db.users.push(newUser);
    saveDB();

    const token = jwt.sign(
      { id: newUser.id, role: newUser.role, name: newUser.name, email: newUser.email },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    const { passwordHash: _, ...userWithoutPass } = newUser;
    res.json({ token, user: userWithoutPass, message: 'Registration successful!' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Login User
 */
router.post('/login', async (req, res) => {
  try {
    const { email, password, demoRole } = req.body;

    const db = getDB();

    // Demo Mode Quick Login
    if (demoRole) {
      const demoUser = db.users.find(u => u.role === demoRole);
      if (demoUser) {
        const token = jwt.sign(
          { id: demoUser.id, role: demoUser.role, name: demoUser.name, email: demoUser.email },
          JWT_SECRET,
          { expiresIn: '7d' }
        );
        const { passwordHash: _, ...userWithoutPass } = demoUser;
        return res.json({ token, user: userWithoutPass, message: `Logged in as Demo ${demoRole}` });
      }
    }

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const user = db.users.find(u => u.email.toLowerCase() === email.toLowerCase().trim());
    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password. Please check your credentials or register.' });
    }

    if (user.passwordHash) {
      const isValid = await bcrypt.compare(password, user.passwordHash);
      if (!isValid) {
        return res.status(401).json({ error: 'Invalid email or password.' });
      }
    }

    const token = jwt.sign(
      { id: user.id, role: user.role, name: user.name, email: user.email },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    const { passwordHash: _, ...userWithoutPass } = user;
    res.json({ token, user: userWithoutPass, message: 'Login successful!' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Get Current Authenticated User
 */
router.get('/me', (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'No authentication token provided' });
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const db = getDB();
    const user = db.users.find(u => u.id === decoded.id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    const { passwordHash: _, ...userWithoutPass } = user;
    res.json({ user: userWithoutPass });
  } catch (err) {
    res.status(401).json({ error: 'Invalid or expired session token' });
  }
});

module.exports = router;
