const express = require('express');
const router = express.Router();
const { getDB, saveDB, generateId } = require('../db/store');

/**
 * Get Workspace Context by Team ID or Problem ID
 */
router.get('/details', (req, res) => {
  try {
    const { teamId, problemId } = req.query;
    const db = getDB();

    let team = null;
    if (teamId) {
      team = db.teams.find(t => t.id === teamId);
    } else if (problemId) {
      team = db.teams.find(t => t.problemId === problemId);
    }

    if (!team) {
      return res.status(404).json({ error: 'Project workspace not found for specified team/problem.' });
    }

    const problem = db.problems.find(p => p.id === team.problemId);
    const milestones = db.milestones.filter(m => m.teamId === team.id);
    const tasks = db.tasks.filter(t => t.teamId === team.id);
    const solution = db.solutionSubmissions.find(s => s.teamId === team.id);
    const proposal = db.proposals.find(pr => pr.id === team.proposalId);

    res.json({
      team,
      problem,
      milestones,
      tasks,
      proposal,
      solutionSubmission: solution || null
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Update Milestone Status by University Team (e.g. mark completed)
 */
router.post('/milestones/:id/status', (req, res) => {
  try {
    const { id } = req.params;
    const { status, completionNotes } = req.body; // status: 'in-progress' | 'completed'

    const db = getDB();
    const milestone = db.milestones.find(m => m.id === id);

    if (!milestone) {
      return res.status(404).json({ error: 'Milestone not found' });
    }

    if (status === 'released') {
      return res.status(403).json({ 
        error: 'University teams cannot self-release milestone funds. Milestone funds can only be released by the Industry Partner after reviewing a completed milestone.' 
      });
    }

    milestone.status = status;
    if (completionNotes) milestone.completionNotes = completionNotes;
    milestone.updatedAt = new Date().toISOString();

    saveDB();
    res.json({ message: `Milestone status updated to ${status}`, milestone });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Milestone-Gated Resource Release by Industry Partner
 */
router.post('/milestones/:id/release', (req, res) => {
  try {
    const { id } = req.params;
    const { industryPartnerName, releaseNotes } = req.body;

    const db = getDB();
    const milestone = db.milestones.find(m => m.id === id);

    if (!milestone) {
      return res.status(404).json({ error: 'Milestone not found' });
    }

    // MANDATORY GATE CHECK
    if (milestone.status !== 'completed') {
      return res.status(400).json({ 
        error: `Milestone fund tranche CANNOT be released yet. Current status is '${milestone.status}'. The university team must mark this milestone as 'completed' first before industry approval.` 
      });
    }

    milestone.status = 'released';
    milestone.releasedBy = industryPartnerName || 'Industry Partner';
    milestone.releasedAt = new Date().toISOString();
    milestone.releaseNotes = releaseNotes || 'Milestone verification approved. Funds & resources tranche released.';

    saveDB();
    res.json({ message: 'Milestone resource tranche released successfully', milestone });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Kanban Tasks Management
 */
router.post('/tasks', (req, res) => {
  try {
    const { teamId, title, description, assignedTo, column } = req.body;

    if (!teamId || !title) {
      return res.status(400).json({ error: 'Team ID and task title are required.' });
    }

    const db = getDB();
    const newTask = {
      id: generateId(),
      teamId,
      title,
      description: description || '',
      assignedTo: assignedTo || 'Unassigned',
      column: column || 'todo', // 'todo' | 'in-progress' | 'review' | 'done'
      createdAt: new Date().toISOString()
    };

    db.tasks.push(newTask);
    saveDB();

    res.json({ message: 'Task created', task: newTask });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.patch('/tasks/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { column, title, description, assignedTo } = req.body;

    const db = getDB();
    const task = db.tasks.find(t => t.id === id);

    if (!task) {
      return res.status(404).json({ error: 'Task not found' });
    }

    if (column) task.column = column;
    if (title) task.title = title;
    if (description !== undefined) task.description = description;
    if (assignedTo !== undefined) task.assignedTo = assignedTo;

    saveDB();
    res.json({ message: 'Task updated', task });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Submit Solution Package (University Team)
 */
router.post('/submit-solution', (req, res) => {
  try {
    const { teamId, problemId, summary, artifactsUrl, demoUrl } = req.body;

    if (!teamId || !problemId || !summary) {
      return res.status(400).json({ error: 'Team ID, problem ID, and solution summary are required.' });
    }

    const db = getDB();
    let solution = db.solutionSubmissions.find(s => s.teamId === teamId);

    if (solution) {
      solution.summary = summary;
      solution.artifactsUrl = artifactsUrl || solution.artifactsUrl;
      solution.demoUrl = demoUrl || solution.demoUrl;
      solution.updatedAt = new Date().toISOString();
    } else {
      solution = {
        id: generateId(),
        teamId,
        problemId,
        summary,
        artifactsUrl: artifactsUrl || 'https://github.com/example/civic-innovation-solution',
        demoUrl: demoUrl || 'https://demo.civic-innovation.org',
        submittedAt: new Date().toISOString(),
        adoptedByGovId: null,
        adoptedAt: null
      };
      db.solutionSubmissions.push(solution);
    }

    saveDB();
    res.json({ message: 'Solution package submitted successfully', solution });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Adopt Solution (Government Official)
 */
router.post('/adopt-solution', (req, res) => {
  try {
    const { solutionId, govtOfficialId, departmentName, adoptionNotes } = req.body;

    const db = getDB();
    const solution = db.solutionSubmissions.find(s => s.id === solutionId);

    if (!solution) {
      return res.status(404).json({ error: 'Solution submission not found' });
    }

    solution.adoptedByGovId = govtOfficialId || 'dept-head-1';
    solution.adoptedDepartment = departmentName || 'Department of Water & Urban Infrastructure';
    solution.adoptedAt = new Date().toISOString();
    solution.adoptionNotes = adoptionNotes || 'Formally approved and adopted for city-wide implementation.';

    saveDB();
    res.json({ message: 'Solution officially adopted by government department', solution });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
