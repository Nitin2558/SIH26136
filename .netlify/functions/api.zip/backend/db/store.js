const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DATA_FILE = path.join(__dirname, 'data.json');
const TMP_DATA_FILE = path.join('/tmp', 'data.json');

let db = {
  users: [],
  problems: [],
  votes: [],
  teams: [],
  proposals: [],
  milestones: [],
  tasks: [],
  solutionSubmissions: [],
  aggregationLogs: []
};

// Load initial state if data.json exists
function loadDB() {
  try {
    let sourcePath = DATA_FILE;
    if (fs.existsSync(TMP_DATA_FILE)) {
      sourcePath = TMP_DATA_FILE;
    }
    if (fs.existsSync(sourcePath)) {
      const raw = fs.readFileSync(sourcePath, 'utf8');
      db = JSON.parse(raw);
      if (!db.users) db.users = [];
      if (!db.problems) db.problems = [];
      if (!db.researchEvidence) db.researchEvidence = [];
      if (!db.researchShares) db.researchShares = [];
      if (!db.researchAuditLogs) db.researchAuditLogs = [];
      if (!db.researchEvidenceFiles) db.researchEvidenceFiles = [];
      console.log('[DB Store] Loaded existing state from:', sourcePath);
    } else {
      console.log('[DB Store] Initialized fresh in-memory database store');
    }
  } catch (err) {
    console.error('[DB Store] Error loading data:', err.message);
  }
}

function saveDB() {
  try {
    const dir = path.dirname(DATA_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2), 'utf8');
  } catch (err) {
    // Fallback to /tmp directory on serverless read-only platforms (e.g. Netlify / AWS Lambda)
    try {
      fs.writeFileSync(TMP_DATA_FILE, JSON.stringify(db, null, 2), 'utf8');
    } catch (tmpErr) {
      // In-memory state remains updated
    }
  }
}

// Initial load
loadDB();

function generateId() {
  if (crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return 'id-' + Math.random().toString(36).substring(2, 9) + '-' + Date.now().toString(36);
}

module.exports = {
  getDB: () => db,
  saveDB,
  generateId,
  resetDB: (newDb) => {
    db = newDb;
    saveDB();
  }
};
