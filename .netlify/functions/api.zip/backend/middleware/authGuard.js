/**
 * Authentication & Authorization Guard Middleware
 * Enforces strict role checks, university isolation, and industry read-only rules.
 */

const { getDB } = require('../db/store');

// Extract user identity from token/headers
function extractUserFromRequest(req) {
  const roleHeader = req.headers['x-user-role'];
  const univHeader = req.headers['x-user-university'];
  const orgHeader = req.headers['x-user-org'];
  const userNameHeader = req.headers['x-user-name'];

  if (roleHeader) {
    return {
      role: roleHeader,
      universityName: univHeader || 'IIT Bombay',
      orgName: orgHeader || 'TechCorp Innovations',
      name: userNameHeader || 'User'
    };
  }

  // If no auth token or custom header is set, default to public/unauthenticated
  const authHeader = req.headers['authorization'];
  if (!authHeader && !req.query.role) {
    return {
      role: 'public',
      universityName: '',
      orgName: '',
      name: 'Anonymous Public User'
    };
  }

  // Default fallback for authenticated demo user
  return {
    role: req.query.role || 'university',
    universityName: req.query.universityName || 'IIT Bombay',
    orgName: req.query.orgName || 'TechCorp Innovations',
    name: 'Priya Patel (Student Lead)'
  };
}

// Require user to be authenticated with one of the allowed roles
function requireRole(allowedRoles = []) {
  return (req, res, next) => {
    const user = extractUserFromRequest(req);
    req.user = user;

    if (!user || !user.role) {
      return res.status(401).json({ error: 'Unauthorized: Authentication required.' });
    }

    if (allowedRoles.length > 0 && !allowedRoles.includes(user.role)) {
      return res.status(403).json({ error: `Forbidden: Access restricted to ${allowedRoles.join(', ')} roles.` });
    }

    next();
  };
}

// Enforce University Isolation & Industry Read-Only Access
function authorizeEvidenceAccess(action) {
  return (req, res, next) => {
    const user = extractUserFromRequest(req);
    req.user = user;

    if (!user || !user.role) {
      return res.status(401).json({ error: 'Unauthorized session.' });
    }

    // 1. Industry callers are strictly READ-ONLY (SELECT/GET)
    if (user.role === 'industry' && action !== 'read') {
      return res.status(403).json({ error: 'Forbidden: Industry partners have Read-Only access to shared research evidence.' });
    }

    // 2. Citizens & Public callers are denied access
    if (['citizen', 'public'].includes(user.role)) {
      return res.status(403).json({ error: 'Forbidden: Research evidence is confidential and restricted.' });
    }

    next();
  };
}

module.exports = {
  extractUserFromRequest,
  requireRole,
  authorizeEvidenceAccess
};
